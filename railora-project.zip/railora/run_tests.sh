#!/bin/sh
cd "$(dirname "$0")" && python3 -X dev -W error::ResourceWarning -m unittest discover -s backend/tests -v
