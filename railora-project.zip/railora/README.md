# RAILORA (development build, NOT production-ready)
Railway availability discovery: direct trains, date-wise search, nearby stations, two-ticket alternatives.
**No real railway provider is connected or verified.** Demo mode uses clearly labelled synthetic fixtures.

## Layout
```
backend/engine.py        rules: statuses, WL 1-5, passengers, stale check, fares, 2-leg routes
backend/service.py       station DB (sqlite), search service, cache, nearby, validation, demo/production gate
backend/api.py           stdlib WSGI API + serves the frontend at /
backend/fastapi_app.py   FastAPI wrapper (UNVERIFIED until run)
backend/providers/       interface, capability registry, unverified stubs, demo (synthetic) provider
backend/migrations/      001_stations.sql
backend/tests/           unit + integration tests
public/                  index.html (frontend), brand/*.svg
docs/                    continuity documents
```
## Run tests (no installs needed, Python 3.10+)
    ./run_tests.sh            # runs: python3 -X dev -W error::ResourceWarning -m unittest discover -s backend/tests -v
The FastAPI test is skipped automatically unless `fastapi` is installed.

## Start (stdlib server, verified)
    export RAILORA_MODE=demo AVAILABILITY_TTL_SECONDS=60 RAILORA_DB_PATH=./railora.db
    python3 backend/api.py          # http://127.0.0.1:10000  (frontend + API, DEMO banner shown)
Demo fixtures only exist for 2026-12-01 and 2026-12-02 (e.g. Jaunpur Jn to LTT).
`RAILORA_MODE=production` refuses synthetic data and returns 503 NO_VERIFIED_PROVIDER until a real adapter is verified.

## Start (FastAPI, UNVERIFIED: needs network to install)
    python3 -m venv .venv && . .venv/bin/activate && pip install -r requirements-dev.txt
    cd backend && uvicorn fastapi_app:app --port 8000
Then run `./run_tests.sh` again: the wrapper test should stop skipping. Report any failure; do not assume it works.

## Database
sqlite schema is applied automatically on start (`migrations/001_stations.sql`, idempotent) and the station table is seeded once (11 placeholder stations). Postgres is NOT implemented yet.

## Cache
Availability is cached `AVAILABILITY_TTL_SECONDS` (default 60, range 1-300). Cached results are flagged `cached: true` with the ORIGINAL `checked_at`, `age_seconds` and `source`; the UI shows "Cached result from HH:MM". Failed checks are never cached and never shown as "not available".

## Needs a network-enabled environment
pip install of fastapi/uvicorn; research and live testing of any provider (RailCore, RailRadar, IndianRailAPI, Qrail, data.gov.in); provider API keys; real station dataset download; Postgres/Redis; browser/mobile testing; deployment.
To connect a provider: implement an adapter in backend/providers/ with `trains_between` and `get_availability` (normalized as in providers/demo.py), live-test it, then set its `capabilities`, and add it to the provider list in `api.make_app`.

## Provider integration
See docs/API_RESEARCH.md (checklist, nothing verified) and docs/PROVIDER_ADAPTER_GUIDE.md. Harness: `python3 backend/tools/verify_provider.py ...` (refuses until a real adapter is registered).

## RailCore
See docs/RAILCORE_INTEGRATION.md. Disabled until `RAILCORE_VERIFIED_OPS` is set. Production needs `RAILCORE_API_KEY` in the server environment and both `get_availability,trains_between` verified. Live tests (cost requests): `RAILORA_LIVE_TESTS=1 python3 -m unittest discover -s backend/tests/live -v`.

## Deploy on Render Free (phone-friendly)
Repo root needs only: `Dockerfile` + `railora-project.zip` (+ optional `render.yaml`), from deploy/render/. In Render: New > Web Service > Docker, instance type Free; set secrets `RAILCORE_API_KEY` and `RAILORA_ACCESS_CODE` in Environment; health check path `/health`. Then open `/verify`, run the live check, and only if both checks pass add `RAILCORE_VERIFIED_OPS=get_availability,trains_between`.
