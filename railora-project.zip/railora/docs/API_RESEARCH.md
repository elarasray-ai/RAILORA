# Provider research (checklist, NOT completed)

## Status
- Research performed: **NONE.** This environment has no network (probe of railradar.in returned no HTTP status). Nothing below is verified.
- Verified providers: **0**. Implemented real adapters: **0** (`providers/interface.py` stubs only; `tools/verify_provider.py` REGISTRY is empty).
- Every cell marked `UNVERIFIED` must be filled from the vendor's own documentation and then confirmed by a live test. Do not copy claims from third-party blogs.
- Only statement carried over from the project brief (not independently checked): RailRadar documents that its reservation data is aggregated from external sources and is not authoritative.

## Candidates and where to look
- **RailCore**: railcore.tech/developers
- **RailRadar**: railradar.in/docs
- **IndianRailAPI**: indianrailapi.com
- **Qrail**: qrail.in/developers
- **Open Government Data**: data.gov.in
- **Official: IRCTC / CRIS / NTES**: (contact IRCTC / CRIS; NTES public site)

## Capability matrix (fill after research; then confirm by live test)
| Capability | RailCore | RailRadar | IndianRailAPI | Qrail | Open Government Data | Official: IRCTC / CRIS / NTES |
|---|---|---|---|---|---|---|
| Station search | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED |
| Trains between stations | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED |
| Date-wise seat availability | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED |
| Class + quota availability | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED |
| Actual fare | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED |
| Train schedule | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED | UNVERIFIED |

Data.gov.in is expected (unconfirmed) to be relevant only for static station/timetable datasets, not live availability. The official IRCTC/CRIS route may require a commercial agreement; confirm directly. Do not assume either.

### RailCore
| Field | Finding | Source link | Date checked |
|---|---|---|---|
| Official documentation URL (confirm it is the vendor's own) | UNVERIFIED | | |
| Base URL | UNVERIFIED | | |
| Authentication method | UNVERIFIED | | |
| Free tier / pricing | UNVERIFIED | | |
| Rate limits | UNVERIFIED | | |
| Data freshness (cache age, source of truth) | UNVERIFIED | | |
| Commercial-use permission (written ToS clause) | UNVERIFIED | | |
| Station search endpoint | UNVERIFIED | | |
| Trains-between-stations endpoint | UNVERIFIED | | |
| Date-wise seat availability endpoint | UNVERIFIED | | |
| Class- and quota-wise availability | UNVERIFIED | | |
| Fare endpoint (actual fare, not estimate) | UNVERIFIED | | |
| Stated reliability / SLA | UNVERIFIED | | |
| Failure behaviour (timeouts, error codes, empty vs error) | UNVERIFIED | | |
| Data-retention / caching restrictions | UNVERIFIED | | |

### RailRadar
| Field | Finding | Source link | Date checked |
|---|---|---|---|
| Official documentation URL (confirm it is the vendor's own) | UNVERIFIED | | |
| Base URL | UNVERIFIED | | |
| Authentication method | UNVERIFIED | | |
| Free tier / pricing | UNVERIFIED | | |
| Rate limits | UNVERIFIED | | |
| Data freshness (cache age, source of truth) | UNVERIFIED | | |
| Commercial-use permission (written ToS clause) | UNVERIFIED | | |
| Station search endpoint | UNVERIFIED | | |
| Trains-between-stations endpoint | UNVERIFIED | | |
| Date-wise seat availability endpoint | UNVERIFIED | | |
| Class- and quota-wise availability | UNVERIFIED | | |
| Fare endpoint (actual fare, not estimate) | UNVERIFIED | | |
| Stated reliability / SLA | UNVERIFIED | | |
| Failure behaviour (timeouts, error codes, empty vs error) | UNVERIFIED | | |
| Data-retention / caching restrictions | UNVERIFIED | | |

### IndianRailAPI
| Field | Finding | Source link | Date checked |
|---|---|---|---|
| Official documentation URL (confirm it is the vendor's own) | UNVERIFIED | | |
| Base URL | UNVERIFIED | | |
| Authentication method | UNVERIFIED | | |
| Free tier / pricing | UNVERIFIED | | |
| Rate limits | UNVERIFIED | | |
| Data freshness (cache age, source of truth) | UNVERIFIED | | |
| Commercial-use permission (written ToS clause) | UNVERIFIED | | |
| Station search endpoint | UNVERIFIED | | |
| Trains-between-stations endpoint | UNVERIFIED | | |
| Date-wise seat availability endpoint | UNVERIFIED | | |
| Class- and quota-wise availability | UNVERIFIED | | |
| Fare endpoint (actual fare, not estimate) | UNVERIFIED | | |
| Stated reliability / SLA | UNVERIFIED | | |
| Failure behaviour (timeouts, error codes, empty vs error) | UNVERIFIED | | |
| Data-retention / caching restrictions | UNVERIFIED | | |

### Qrail
| Field | Finding | Source link | Date checked |
|---|---|---|---|
| Official documentation URL (confirm it is the vendor's own) | UNVERIFIED | | |
| Base URL | UNVERIFIED | | |
| Authentication method | UNVERIFIED | | |
| Free tier / pricing | UNVERIFIED | | |
| Rate limits | UNVERIFIED | | |
| Data freshness (cache age, source of truth) | UNVERIFIED | | |
| Commercial-use permission (written ToS clause) | UNVERIFIED | | |
| Station search endpoint | UNVERIFIED | | |
| Trains-between-stations endpoint | UNVERIFIED | | |
| Date-wise seat availability endpoint | UNVERIFIED | | |
| Class- and quota-wise availability | UNVERIFIED | | |
| Fare endpoint (actual fare, not estimate) | UNVERIFIED | | |
| Stated reliability / SLA | UNVERIFIED | | |
| Failure behaviour (timeouts, error codes, empty vs error) | UNVERIFIED | | |
| Data-retention / caching restrictions | UNVERIFIED | | |

### Open Government Data
| Field | Finding | Source link | Date checked |
|---|---|---|---|
| Official documentation URL (confirm it is the vendor's own) | UNVERIFIED | | |
| Base URL | UNVERIFIED | | |
| Authentication method | UNVERIFIED | | |
| Free tier / pricing | UNVERIFIED | | |
| Rate limits | UNVERIFIED | | |
| Data freshness (cache age, source of truth) | UNVERIFIED | | |
| Commercial-use permission (written ToS clause) | UNVERIFIED | | |
| Station search endpoint | UNVERIFIED | | |
| Trains-between-stations endpoint | UNVERIFIED | | |
| Date-wise seat availability endpoint | UNVERIFIED | | |
| Class- and quota-wise availability | UNVERIFIED | | |
| Fare endpoint (actual fare, not estimate) | UNVERIFIED | | |
| Stated reliability / SLA | UNVERIFIED | | |
| Failure behaviour (timeouts, error codes, empty vs error) | UNVERIFIED | | |
| Data-retention / caching restrictions | UNVERIFIED | | |

### Official: IRCTC / CRIS / NTES
| Field | Finding | Source link | Date checked |
|---|---|---|---|
| Official documentation URL (confirm it is the vendor's own) | UNVERIFIED | | |
| Base URL | UNVERIFIED | | |
| Authentication method | UNVERIFIED | | |
| Free tier / pricing | UNVERIFIED | | |
| Rate limits | UNVERIFIED | | |
| Data freshness (cache age, source of truth) | UNVERIFIED | | |
| Commercial-use permission (written ToS clause) | UNVERIFIED | | |
| Station search endpoint | UNVERIFIED | | |
| Trains-between-stations endpoint | UNVERIFIED | | |
| Date-wise seat availability endpoint | UNVERIFIED | | |
| Class- and quota-wise availability | UNVERIFIED | | |
| Fare endpoint (actual fare, not estimate) | UNVERIFIED | | |
| Stated reliability / SLA | UNVERIFIED | | |
| Failure behaviour (timeouts, error codes, empty vs error) | UNVERIFIED | | |
| Data-retention / caching restrictions | UNVERIFIED | | |

## Rules (non-negotiable)
- No scraping of IRCTC or any protected booking site; no bypassing authentication, captchas or rate limits.
- Read and record the commercial-use clause before using a provider in a product. Free tiers often forbid commercial use: check.
- Availability and fare must come from the same provider call or be clearly labelled as separate sources. Never combine a schedule source and an availability source silently.
- A provider that labels data non-authoritative must be shown to users with that caveat and never described as official.

## Live test protocol (network-enabled environment, real key)
1. Put the key in the environment (never in code). Implement the adapter (see PROVIDER_ADAPTER_GUIDE.md).
2. Run `python3 backend/tools/verify_provider.py --provider NAME --frm X --to Y --date YYYY-MM-DD --cls 3A` for at least 5 route/date/class combinations, including one overnight route and one multi-day-ahead date.
3. Cross-check at least 3 results against a second independent source (the operator's own site viewed manually). Record mismatches.
4. Error behaviour, each recorded: invalid station, past date, date beyond booking window, unsupported class, wrong/expired key, rate-limit hit, provider timeout. Confirm each maps to a ProviderError and never to "not available".
5. Measure latency (p50/p95 over 20 calls) and the real rate limit.
6. Record the raw response shape (field names only, no keys) in `docs/verification/NAME-DATE.json` and summarise here.

## Acceptance gate for enabling a capability
All must be true: live call succeeded on 5+ cases; schema valid (harness); 3+ cross-checks match or differences explained; commercial use permitted in writing; failure modes mapped; limits fit expected traffic. Only then set `capabilities[op]=True` for that op, and record date, evidence and reviewer in API_INTEGRATION_STATUS.md.

## RailCore: findings from vendor docs (14 Nov 2026)
Documented: base URL https://ir.railcore.tech/v1; auth header X-RailCore-Key (also Bearer / X-Api-Key); scopes availability:read, journeys:read; availability and trains-between cost 1 request each, failed requests free; Free tier 500 requests/month (docs page meta); HMAC required for Growth+ plans; availability can be answered from an upstream cache (last_updated_at may be hours old); trains-between availability_summary can be days old and must not be shown as fresh. STILL UNVERIFIED: commercial-use terms, pricing, per-minute limits, remaining-quota headers, live behaviour through this adapter. Details: RAILCORE_INTEGRATION.md.
