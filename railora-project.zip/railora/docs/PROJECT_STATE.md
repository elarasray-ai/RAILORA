# State (Phase 1)
Done: pure-Python rules engine (backend/engine.py), provider interface + registry (UNVERIFIED stubs), 31 unit tests passing, brand SVGs, hosted demo UI (public/index.html).
Next exact step: install FastAPI/Postgres/Redis in a networked env, wrap engine in API routes, verify one provider.

## Milestone 2
Done: sqlite station DB + migration (backend/migrations), SearchService (validation, date-wise parallel search, TTL cache, nearby, 2-ticket routes, demo/production gate), stdlib WSGI API (/health /api/stations /api/nearby /api/search, rate limit, sanitized errors), FastAPI wrapper (UNTESTED), UI patched (recent-search dedupe, suggestions close on outside tap, honest demo label, optional ?api= backend mode).
Tests: 55 passing. UI API mode and FastAPI wrapper not run.

## Milestone 3 (packaging/verification)
Cache TTL default 60s, cached results flagged with original timestamp+source. Frontend: date range (<=7), nearby selection (backend mode), compare up to 3. API serves frontend at /. README, requirements, env example, run_tests.sh, ZIP.

## Milestone 4
ResourceWarnings fixed (files in with-blocks, StationDB/SearchService/app close(), context managers, __del__ safety net). Strict validation (types, ranges, finite budget, strict dates, code regex, unknown keys, nearby_codes<=10), API limits (body 16 KB default, content-type, content-length, query length, JSON depth), rate limiter sweep+cap. HttpAdapter base (retry/backoff/breaker/safe errors), verification harness, research checklist and adapter guide. Suite now run with ResourceWarning as errors.

## Milestone 5 (RailCore)
Adapter + doc-shaped mocked tests (45 new), freshness/stale/not-live handling, per-search call budget, routes fallback mode, strict demo/production provider separation, live test suite (opt-in), harness registry entry. UI shows provider update time and notices.

## Milestone 6 (deployment)
Threaded stdlib server bound via HOST/PORT; production access-code gate (RAILORA_ACCESS_CODE, min 8 chars; search and live-check refused without it); /verify phone page + POST /api/admin/verify (evidence only, 30s cooldown, never enables capabilities); ROUTES_MODE=off; 27 placeholder stations; UI uses /api/stations and sends access code. Target host: Hugging Face Spaces (Docker, free CPU). deploy/huggingface/Dockerfile. Not deployed by this project: needs the owner's account.

## Milestone 7 (Render Free target)
Hugging Face dropped (needs PRO). Target: Render Free web service, Docker runtime, repo = Dockerfile + ZIP. Port: $PORT default 10000, bind 0.0.0.0 (also auto when RENDER=true). deploy/render/{Dockerfile,render.yaml}. Not deployed.
