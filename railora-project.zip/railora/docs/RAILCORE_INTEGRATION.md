# RailCore integration (adapter: backend/providers/railcore.py)

## Sources read (14 Nov 2026, vendor docs only)
- https://railcore.tech/docs/api/seat-availability
- https://railcore.tech/docs/api/route-trains
- https://railcore.tech/docs/responses
NOT read: authentication guide, HMAC signing, rate-limits, requests/billing, error catalog, header reference, pricing, terms of service, every other endpoint page. Nothing from those is assumed.

## Status
| Operation | Endpoint | Implemented | Live-verified | Enabled by default |
|---|---|---|---|---|
| get_availability | GET /v1/availability/seats | yes | Reported OK by the project owner (HTTP 200, success, mode live) in their own test. NOT yet reproduced through this adapter / harness | no |
| trains_between | GET /v1/routes/trains | yes | no (never called live) | no |
| fares | fare comes from availability `total_fare`; separate fare endpoints not read | no | no | no |
| station search, train search, schedule, running status | pages exist in docs, not read | no (raise NotConfigured) | no | no |

This project's sandbox cannot reach ir.railcore.tech. No live RailCore call has been made by this code. All adapter tests use a local mock shaped like the documented examples.

## Requests (exact documented names)
- Auth: header `X-RailCore-Key`, key read ONLY from env `RAILCORE_API_KEY`. Free/Starter keys send the key alone. Growth/Scale/Enterprise keys also need HMAC (X-RailCore-Timestamp/Nonce/Signature): NOT implemented; such keys will get 401 SIGNATURE_INVALID, surfaced as "Provider rejected the credentials."
- availability: `train_number` (4-6 A-Z0-9), `from`, `to`, `date` (YYYY-MM-DD), `class`, `quota` (optional; we always send it). Inputs are validated locally before any request.
- trains between: `from`, `to`, `date`, `match=station` (so results are exactly the stations asked; the service handles nearby stations itself).

## Normalisation (RailCore -> RAILORA)
- Provider `status` always wins. REGRET stays REGRET even if a count looks positive (tested).
- AVAILABLE + count n>0 -> `AVAILABLE-n`; count null -> `AVAILABLE` (count unknown: only valid for 1 passenger); count 0 or count/text disagree -> UNKNOWN.
- WAITLIST -> `WL<current waitlist_count>` (falls back to position in text); RAC -> `RAC n`; NOT_AVAILABLE -> `NOT AVAILABLE`; TRAIN_CANCELLED / TRAIN_DEPARTED kept; anything else -> UNKNOWN. Only AVAILABLE (and WL 1-5 on request) is displayed.
- `confirmation_probability` is a forecast: passed through as `forecast`, never used to confirm.
- Fare = `total_fare` (INR, null if absent). Assumed per passenger: VERIFY live.
- Freshness kept per result: `provider_updated_at` (classes[].last_updated_at, may be hours old per docs), `retrieved_at` (meta.freshness.retrieved_at), `freshness_mode` (only `live` counts as live; anything else is hidden), `source`, our own `checked_at`, `cached`, `age_seconds`, plus `request_id`.
- Data older than PROVIDER_MAX_AGE_SECONDS (default 3600, our choice, tune it) is hidden with a notice. Missing provider timestamp is shown as unknown, not as fresh.
- trains between: HH:mm departure taken on the journey date (IST); arrival = departure + duration_minutes. Records whose arrival_time disagrees, or whose stations differ from the request, are dropped (counted in `provider.dropped`), never repaired. Malformed records fail the whole response.

## Errors
422 TATKAL/QUOTA/CLASS/TRAIN_NOT_RUNNING/BOOKING_NOT_OPEN and 404 NO_TRAINS_FOUND = legitimate non-results (notices, not failures). 401/403 auth, 402 allowance used up, 429 rate-limited (Retry-After kept, no inline retry), 5xx/timeouts retried at most twice with backoff then circuit breaker. 400/410/other = bad response. User-facing messages never contain the key, URL or upstream text.

## Cost control (the Free tier is documented as 500 requests a month)
Each availability or trains-between call is 1 request. Controls: PROVIDER_MAX_CALLS_PER_SEARCH, ROUTES_MODE=fallback, class pre-filter from the trains list, 60 s cache. Interchange search still tries every station in the DB: set fallback + a low cap until the timetable-graph work is done.

## Enabling (human step)
1. Put RAILCORE_API_KEY in the server environment. 2. `python3 backend/tools/verify_provider.py --provider railcore --frm X --to Y --date YYYY-MM-DD --cls 3A` and `RAILORA_LIVE_TESTS=1 python3 -m unittest discover -s backend/tests/live -v` (each costs requests). 3. Compare against an independent source. 4. Set RAILCORE_VERIFIED_OPS. Production search needs BOTH get_availability and trains_between, otherwise the API returns 503 NO_VERIFIED_PROVIDER. 5. Read RailCore's terms for commercial use before launch.
