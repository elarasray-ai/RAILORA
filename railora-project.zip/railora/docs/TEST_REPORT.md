# Tests
python3 -m unittest discover -s backend/tests  -> 31 tests OK. Covers stations/aliases, status parsing, confirmed-only, WL1-5, WL6+, RAC/regret, pax count, class/date independence, stale/unverified data, API-failure-is-error, fares, 2-leg routes, overnight, buffers, station change, budget, max two tickets, nearby ranking. Synthetic fixtures only.

## Milestone 2
55 tests OK (31 engine + 24 service/API). Not covered: FastAPI wrapper, browser UI, real providers, Postgres/Redis.

## Milestone 3: 64 tests, 63 pass, 1 skipped (FastAPI wrapper: fastapi not installed).
Verified by test: sqlite init/reopen/idempotent migration, Config env parsing, cache TTL/cached flag/original timestamp, nearby selection, 7-date limit, real HTTP server round trip on localhost (/health, /, /api/search, 404), production-mode 503.
NOT verified: FastAPI, browser UI behaviour (only JS syntax + rng() logic checked in node), real providers, mobile layout.

## Milestone 4: 95 tests, 94 pass, 1 skipped (FastAPI not installed), run with -X dev -W error::ResourceWarning.
New: resource closing, validation matrix, request-size/media-type/content-length/query limits, rate-limiter sweep, HttpAdapter against a localhost test server (retry, backoff, caps, auth/429/bad JSON/timeout, no leaks, circuit breaker), harness schema + synthetic refusal.
Not verified: any real provider, FastAPI, browser UI. HttpAdapter tested only against a local fake server.

## Milestone 5: 140 tests, 139 pass, 1 skipped (FastAPI not installed). MOCKED RailCore tests: exact params/headers, every status, REGRET never confirmed, timestamps, errors (402/401/403/422/429/5xx/timeout/refused/garbage), missing key (no request sent), env-only key, key never in outputs, trains-between mapping, service end-to-end (freshness, cache, budget, notices, mode separation).
LIVE tests (backend/tests/live, opt-in, cost requests): written, NOT run. No real RailCore call has been made by this code.
