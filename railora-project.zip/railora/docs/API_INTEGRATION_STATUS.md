# Integration status
railcore: UNVERIFIED | railradar: UNVERIFIED | indianrailapi: UNVERIFIED | qrail: no adapter | official: none. Nothing is operational. Required per provider: API key, availability + fare + trains-between + schedule endpoints, commercial-use permission.

## Milestone 2
Production mode refuses the demo provider and returns 503 NO_VERIFIED_PROVIDER until a real adapter has get_availability+trains_between capabilities set. Still no verified provider.

## Milestone 5
railcore: adapter implemented for get_availability and trains_between from vendor docs; mocked tests only. Owner reports a successful availability call (12656 BSL-ADI 3A GN, REGRET, fare 965, mode live) made outside this project. Capabilities stay DISABLED until RAILCORE_VERIFIED_OPS is set after harness/live evidence. Other endpoints not implemented.
