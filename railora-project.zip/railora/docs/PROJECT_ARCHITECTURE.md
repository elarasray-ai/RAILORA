# Architecture
engine.py = business rules (no I/O). providers/ = adapters behind capability registry (op enabled only after live test). UI = static prototype using demo fixtures; production UI should be Next.js calling the FastAPI backend. Station list in engine.py is a small reference set, not a full dataset.
