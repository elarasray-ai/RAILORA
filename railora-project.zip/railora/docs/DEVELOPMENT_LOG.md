# Log
Phase 1: environment has no network, pip, pytest or FastAPI. Built stdlib-only core + unittest. Prototype UI duplicates engine rules in JS for demo only.

## Milestone 2
Found by tests: per-date errors leaked raw exception text (fixed: only ProviderError messages are shown). Demo UI labelled "Last checked" on page-load time (now "Demo data, not a live check").
