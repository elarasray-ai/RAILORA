# Known issues
- Mobile viewport review NOT done: no browser in this environment. Static code review only.
- Hosted artifact cannot call a backend (CSP); API mode works only when self-hosted with ?api=.
- No real provider; no provider research (no network). Station list is 11 placeholder stations; coordinates approximate.
- Nearby relevance is distance-only (no connectivity data yet). Interchange search tries every station in DB: needs a real graph for scale.
- sqlite instead of Postgres; in-memory cache instead of Redis; no circuit breaker/retry yet; rate limiter is in-process.
- UI lacks date-range picker, comparison view, nearby station selection controls.
- FastAPI wrapper untested.

## Milestone 3
Frontend never rendered in a browser. Compare/date-range/nearby UI untested beyond syntax. TTL cache is per-process memory. engine.TTLCache/nearby/safe_availability are tested helpers not wired into the service (service has its own cache).

## Status after Milestone 4
Fixed: SQLite/file ResourceWarnings; rate limiter cleanup and request-size protection. STILL OPEN from audit: 11 placeholder stations; distance-only nearby ranking; interchange search tries every station. Rate limiter is still in-process and trusts REMOTE_ADDR (behind a proxy it needs X-Forwarded-For handling or an edge limiter).

## Milestone 5
No live verification through the adapter. HMAC signing unsupported. Total fare assumed per passenger; trains-between time semantics assumed (departure on journey date). Commercial terms unread. 11 placeholder stations: real RailCore queries for stations outside the DB are rejected by validation. Interchange search burns requests (use fallback + call cap).

## Milestone 6
Not deployed or live-tested yet (needs owner's HF account + RailCore key). Free Spaces sleep after ~48h idle (cold start). Access code is a shared secret; wrong-attempt limiter is a single shared bucket (an attacker can lock the owner out for 5 min but cannot brute-force). 27 placeholder stations: only the codes in the DB can be searched. Server is stdlib wsgiref (fine for personal use, not for heavy traffic).

## Milestone 7 (Render Free)
Free service spins down after 15 min idle (up to ~1 min cold start), may restart anytime, ephemeral filesystem (we use in-memory sqlite: nothing is lost that matters; cache, rate limits and cooldown reset on restart). 750 free instance hours/month. Real Render build NOT run. Unchecked: RailCore IP allowlisting vs Render's outbound IPs; whether Render asks for identity/card verification on signup (official docs say no payment required; third-party reports differ).
