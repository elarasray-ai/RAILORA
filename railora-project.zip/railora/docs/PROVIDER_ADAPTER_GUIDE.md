# Provider adapter architecture

## Contract (providers/interface.py)
Ops: search_stations, search_trains, get_schedule, trains_between, get_availability, get_fare, get_running_status. An op works only if the adapter implements it AND `capabilities[op]` is True (set manually after the acceptance gate). Unimplemented ops raise NotConfigured.
The search service needs: `trains_between(frm, to, date) -> [{train:str, name:str, frm, to, dep:datetime, arr:datetime}]` and `get_availability(train, frm, to, date, cls, quota) -> {status:str, fare:number|None}`. Status strings must parse via `engine.parse_status`; unknown strings are rejected, never guessed. Fare is None if the provider gives none; routes with unknown fares are never budget-verified.

## Building an adapter
1. Subclass `providers.http_base.HttpAdapter` (timeout, capped retry with exponential backoff, circuit breaker, size cap, safe errors). Pass the key from an environment variable; never log or return it.
2. Map each vendor endpoint to the normalized shapes above in one place; convert times to timezone-consistent datetimes (handle overnight and day-change).
3. Raise only ProviderAuthError / ProviderRateLimited / ProviderUnavailable / ProviderBadResponse. Messages must be safe for users.
4. Add a fixture-based unit test using recorded response SHAPES (no real keys, no invented data) to test parsing.
5. Register a factory in `tools/verify_provider.REGISTRY`, run the live protocol (API_RESEARCH.md), then enable capabilities and add the adapter to `api.make_app`.
6. Production mode skips synthetic providers; with no verified provider the API returns 503 NO_VERIFIED_PROVIDER.

## Error mapping
401/403 auth, no retry. 429 rate-limited, no retry. 5xx, timeout, connection error: retry up to max_retries, then breaker counts a failure. Other 4xx and bad JSON: bad response, no retry. Service shows the safe message per date and marks the search incomplete.

## Open design work (from audit; not started)
- Station DB: load a licensed station dataset (e.g. data.gov.in, if its licence permits) via a migration/loader; keep the 11 placeholder rows only for demo mode.
- Nearby ranking: needs connectivity (trains per station pair from a timetable source) in addition to distance; until then it is labelled `distance_only`.
- Interchange search: replace "try every station" with candidates derived from timetable graph (stations served by trains from the origin that also serve trains to the destination), capped by a relevance score.
