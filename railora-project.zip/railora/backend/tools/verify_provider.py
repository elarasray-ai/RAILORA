"""Live-verification harness. Run ONLY in a network-enabled environment with real credentials.
It records evidence; it never flips capability flags. A human reviews the report, then sets Provider.capabilities."""
import json, os, sys, time
from datetime import datetime, timezone
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from engine import parse_status
from providers.interface import ProviderError, NotConfigured
def _railcore():
    from providers.railcore import RailCoreProvider; return RailCoreProvider()  # key from env RAILCORE_API_KEY only
REGISTRY = {"railcore": _railcore}  # an entry means "adapter exists", NOT "verified"
def validate_normalized(kind, o):
    num = lambda v: isinstance(v, (int, float)) and not isinstance(v, bool)
    if kind == "train": return isinstance(o, dict) and all(isinstance(o.get(k), str) and o[k] for k in ("train", "name", "frm", "to")) and all(isinstance(o.get(k), datetime) for k in ("dep", "arr")) and o["arr"] > o["dep"]
    if kind == "availability": return isinstance(o, dict) and parse_status(o.get("status"))[0] != "UNKNOWN" and (o.get("fare") is None or (num(o["fare"]) and o["fare"] >= 0))
    return False
def _summ(name, res):
    iso = lambda x: x.isoformat() if hasattr(x, "isoformat") else x
    if name == "trains_between": t = res[0]; return {"count": len(res), "first": {k: iso(t.get(k)) for k in ("train", "name", "dep", "arr", "classes")}}
    return {k: iso(res.get(k)) for k in ("status", "fare", "live", "freshness_mode", "provider_updated_at", "retrieved_at", "provider_status", "source")}
def run_checks(prov, frm, to, date, cls="3A", quota="GN"):
    if getattr(prov, "synthetic", False): raise ValueError("Synthetic providers cannot be verified.")
    rep = {"provider": prov.name, "run_at": datetime.now(timezone.utc).isoformat(), "inputs": dict(frm=frm, to=to, date=date, cls=cls, quota=quota), "checks": {}}
    def check(name, fn, valid):
        t = time.monotonic()
        try:
            res = fn(); ok = valid(res); rep["checks"][name] = {"called": True, "schema_valid": ok, "latency_s": round(time.monotonic() - t, 3), "error": None, "message": None}
            if ok: rep["checks"][name]["sample"] = _summ(name, res)
            return res
        except Exception as e: rep["checks"][name] = {"called": True, "schema_valid": False, "latency_s": round(time.monotonic() - t, 3), "error": type(e).__name__, "message": str(e) if isinstance(e, (ProviderError, NotConfigured)) else None}
    trains = check("trains_between", lambda: prov.trains_between(frm, to, date), lambda r: bool(r) and all(validate_normalized("train", x) for x in r))
    if trains:
        pick = next((x for x in trains if "classes" not in x or cls in x["classes"]), trains[0])
        check("get_availability", lambda: prov.get_availability(pick["train"], frm, to, date, cls, quota), lambda r: validate_normalized("availability", r))
    rep["note"] = "Evidence only. Compare against an independent source before enabling any capability."
    return rep
if __name__ == "__main__":
    import argparse
    a = argparse.ArgumentParser(); [a.add_argument(f"--{k}", required=k in ("provider", "frm", "to", "date")) for k in ("provider", "frm", "to", "date", "cls", "quota")]; a = a.parse_args()
    if a.provider not in REGISTRY: sys.exit(f"No adapter implemented for '{a.provider}'. Nothing was tested.")
    r = run_checks(REGISTRY[a.provider](), a.frm, a.to, a.date, a.cls or "3A", a.quota or "GN"); print(json.dumps(r, indent=1))
