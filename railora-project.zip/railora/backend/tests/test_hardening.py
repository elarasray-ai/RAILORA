import unittest, sys, os, json, io, gc, sqlite3, warnings, threading, http.server, time
from datetime import datetime, timezone
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from service import *
from api import make_app, RateLimiter
from providers.demo import DemoProvider
from providers.interface import *
from providers.http_base import HttpAdapter, CircuitBreaker
from tools.verify_provider import validate_normalized, run_checks
P = dict(**{"from": "JNU", "to": "LTT"}, date="2026-12-01", pax=1, cls="3A", budget=1000)
def svc():
    s = SearchService(StationDB(), [DemoProvider()], Config()); return s
class Resources(unittest.TestCase):
    def test_close_idempotent_and_blocks_use(self):
        db = StationDB(); db.close(); db.close()
        with self.assertRaises(Exception): db.search("Mumbai")
    def test_context_managers(self):
        with StationDB() as db: self.assertTrue(db.search("Mumbai"))
        self.assertIsNone(db.c)
        with SearchService(StationDB(), [DemoProvider()], Config()) as s: s.search(P)
        self.assertIsNone(s.db.c)
    def test_no_resource_warnings(self):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always", ResourceWarning)
            db = StationDB(); db.search("x"); db.close(); a = make_app(Config()); a.close(); del db, a; gc.collect()
            s = svc(); s.search(P); s.close(); del s; gc.collect()
        self.assertEqual([str(x.message) for x in w if issubclass(x.category, ResourceWarning)], [])
class Call(unittest.TestCase):
    def call(self, app, path="/api/search", method="POST", body=None, qs="", ct="application/json", cl=None):
        raw = body if isinstance(body, bytes) else json.dumps(body).encode() if body is not None else b""; st = {}
        env = {"PATH_INFO": path, "REQUEST_METHOD": method, "QUERY_STRING": qs, "REMOTE_ADDR": "9.9.9.9", "wsgi.input": io.BytesIO(raw),
               "CONTENT_LENGTH": str(len(raw)) if cl is None else cl, "CONTENT_TYPE": ct}
        res = b"".join(app(env, lambda s, h: st.update(s=int(s[:3])))); return st["s"], json.loads(res)
class Limits(Call):
    def setUp(self): self.app = make_app(Config(), max_body=200); self.addCleanup(self.app.close)
    def test_too_large_413(self): self.assertEqual(self.call(self.app, body=dict(P, x="a" * 500))[0], 413)
    def test_declared_large_not_read(self): self.assertEqual(self.call(self.app, body=b"{}", cl="999999999")[0], 413)
    def test_bad_content_length(self):
        for cl in ("abc", "-5"): self.assertEqual(self.call(self.app, body=b"{}", cl=cl)[0], 400)
    def test_media_type(self): self.assertEqual(self.call(self.app, body=P, ct="text/plain")[0], 415)
    def test_charset_param_ok(self): self.assertEqual(self.call(self.app, body=P, ct="application/json; charset=utf-8")[0], 200)
    def test_bad_json_shapes(self):
        for b in (b"[1,2]", b"not json", b"\xff\xfe", b"[" * 5000, b"null", b'"str"'):
            self.assertEqual(self.call(make_app(Config(), max_body=10000), body=b)[0], 400, b[:10])
    def test_nan_budget(self): self.assertEqual(self.call(self.app, body=b'{"from":"JNU","to":"LTT","date":"2026-12-01","budget":NaN}')[0], 400)
    def test_query_limits(self):
        self.assertEqual(self.call(self.app, "/api/stations", "GET", qs="q=" + "a" * 100)[0], 400)
        self.assertEqual(self.call(self.app, "/api/stations", "GET", qs="q=" + "a" * 600)[0], 414)
        self.assertEqual(self.call(self.app, "/api/nearby", "GET", qs="code=JNU';DROP")[0], 400)
        self.assertEqual(self.call(self.app, "/api/nearby", "GET", qs="code=JNU")[0], 200)
class Validation(unittest.TestCase):
    def bad(self, **kw):
        with svc() as s:
            with self.assertRaises(ServiceError) as c: s.search({**P, **kw})
        self.assertEqual(c.exception.code, "INVALID_INPUT")
    def test_types(self):
        for kw in (dict(pax=True), dict(pax=2.0), dict(pax="2"), dict(pax=0), dict(budget=float("inf")), dict(budget=float("nan")), dict(budget=-1), dict(budget=1e12),
                   dict(budget="500"), dict(budget=True), dict(wl="yes"), dict(nearby=1), dict(dates="2026-12-01"), dict(dates=[]), dict(dates=[5]), dict(date="20261201", dates=None),
                   dict(dates=["2026-13-40"]), dict(quota="gn1"), dict(quota=5), dict(cls=3), dict(nearby_codes="ZNP"), dict(nearby_codes=["A"] * 11), dict(nearby_codes=["x y"]),
                   {"from": 5}, {"from": ["JNU"]}, {"from": "JNU; DROP"}, {"from": ""}, dict(unknown_key=1)): self.bad(**kw)
    def test_non_dict(self):
        with svc() as s:
            for b in ([], "x", None, 5):
                with self.assertRaises(ServiceError): s.search(b)
    def test_dates_deduped(self):
        with svc() as s: self.assertEqual([d["date"] for d in s.search(dict(P, dates=["2026-12-01", "2026-12-01", "2026-12-02"]))["dates"]], ["2026-12-01", "2026-12-02"])
    def test_lowercase_codes_ok(self):
        with svc() as s: self.assertEqual(s.search({**P, "from": " jnu "})["mode"], "demo")
class Limiter(unittest.TestCase):
    def test_sweep_and_cap(self):
        t = [0.0]; r = RateLimiter(limit=2, window=10, clock=lambda: t[0], max_keys=50)
        for i in range(30): r.allow(f"ip{i}")
        t[0] = 11; r.sweep(t[0]); self.assertEqual(r.size(), 0)
        for i in range(200): r.allow(f"ip{i}")
        self.assertLessEqual(r.size(), 150)  # growth bounded by periodic sweep + cap
        r.sweep(t[0]); self.assertLessEqual(r.size(), 50)
    def test_limit_and_window(self):
        t = [0.0]; r = RateLimiter(limit=2, window=10, clock=lambda: t[0])
        self.assertEqual([r.allow("a"), r.allow("a"), r.allow("a")], [True, True, False]); self.assertTrue(r.allow("b"))
        t[0] = 10.5; self.assertTrue(r.allow("a"))
class H(http.server.BaseHTTPRequestHandler):
    hits = {}
    def log_message(self, *a): pass
    def do_GET(self):
        p = self.path.split("?")[0]; H.hits[p] = H.hits.get(p, 0) + 1; n = H.hits[p]
        code, body = {"/ok": (200, b'{"a":1}'), "/auth": (401, b"secret-upstream"), "/rl": (429, b""), "/bad": (200, b"<html>"), "/nf": (404, b""), "/big": (200, b"x" * 3_000_000),
                      "/flaky": (503 if n < 3 else 200, b'{"ok":true}'), "/fail": (500, b"")}.get(p, (200, b"{}"))
        if p == "/slow": time.sleep(0.6)
        try: self.send_response(code); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError): pass  # client timed out on purpose
class Http(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H); threading.Thread(target=cls.srv.serve_forever, daemon=True).start(); cls.base = f"http://127.0.0.1:{cls.srv.server_port}"
    @classmethod
    def tearDownClass(cls): cls.srv.shutdown(); cls.srv.server_close()
    def a(self, **kw): self.sl = []; return HttpAdapter(self.base, api_key="KEY-123", sleep=self.sl.append, **kw)
    def test_ok(self): self.assertEqual(self.a()._get("/ok"), {"a": 1})
    def test_retry_exponential_then_success(self):
        H.hits.pop("/flaky", None); a = self.a(); self.assertEqual(a._get("/flaky"), {"ok": True}); self.assertEqual(self.sl, [0.5, 1.0])
    def test_retries_capped(self):
        H.hits.pop("/fail", None); a = self.a(max_retries=2)
        with self.assertRaises(ProviderUnavailable): a._get("/fail")
        self.assertEqual(H.hits["/fail"], 3)
    def test_no_retry_on_auth_rate_client(self):
        for path, exc in (("/auth", ProviderAuthError), ("/rl", ProviderRateLimited), ("/nf", ProviderBadResponse)):
            H.hits.pop(path, None); a = self.a()
            with self.assertRaises(exc): a._get(path)
            self.assertEqual((H.hits[path], self.sl), (1, []))
    def test_bad_json_and_oversize(self):
        for p in ("/bad", "/big"):
            with self.assertRaises(ProviderBadResponse): self.a()._get(p)
    def test_timeout(self):
        with self.assertRaises(ProviderUnavailable): self.a(timeout=0.1, max_retries=0)._get("/slow")
    def test_errors_do_not_leak(self):
        for p in ("/auth", "/fail", "/bad"):
            try: self.a(max_retries=0)._get(p)
            except ProviderError as e: self.assertNotIn("KEY-123", str(e)); self.assertNotIn("secret-upstream", str(e)); self.assertNotIn(self.base, str(e))
    def test_connection_refused(self):
        with self.assertRaises(ProviderUnavailable): HttpAdapter("http://127.0.0.1:1", sleep=lambda s: None, max_retries=1)._get("/x")
    def test_circuit_breaker(self):
        t = [0.0]; H.hits.pop("/fail", None); a = HttpAdapter(self.base, max_retries=0, sleep=lambda s: None, breaker=CircuitBreaker(2, 30, lambda: t[0]))
        for _ in range(2):
            with self.assertRaises(ProviderUnavailable): a._get("/fail")
        with self.assertRaises(ProviderUnavailable): a._get("/fail")
        self.assertEqual(H.hits["/fail"], 2)  # third call never hit the server
        t[0] = 31
        with self.assertRaises(ProviderUnavailable): a._get("/fail")
        self.assertEqual(H.hits["/fail"], 3)
    def test_service_shows_only_safe_provider_message(self):
        class P2(DemoProvider):
            synthetic = False
            def trains_between(self, *a): raise ProviderAuthError("Provider rejected the credentials.")
        with SearchService(StationDB(), [P2()], Config("production")) as s: d = s.search(P)["dates"][0]
        self.assertEqual(d["error"], "Provider rejected the credentials.")
class Harness(unittest.TestCase):
    D = datetime(2026, 12, 1, 8); A = datetime(2026, 12, 1, 12)
    def test_validate(self):
        good = dict(train="1", name="n", frm="A", to="B", dep=self.D, arr=self.A)
        self.assertTrue(validate_normalized("train", good)); self.assertFalse(validate_normalized("train", dict(good, arr=self.D)))
        self.assertFalse(validate_normalized("train", dict(good, dep="08:00"))); self.assertTrue(validate_normalized("availability", {"status": "AVAILABLE-4", "fare": 300}))
        self.assertTrue(validate_normalized("availability", {"status": "GNWL2", "fare": None})); self.assertFalse(validate_normalized("availability", {"status": "???", "fare": 1}))
        self.assertFalse(validate_normalized("availability", {"status": "REGRET", "fare": -5})); self.assertFalse(validate_normalized("x", {}))
    def test_refuses_synthetic(self):
        with self.assertRaises(ValueError): run_checks(DemoProvider(), "JNU", "LTT", "2026-12-01")
    def test_report_records_evidence_not_capabilities(self):
        class Live(Provider):
            name = "fake_live"
            def trains_between(s, f, t, d): return [dict(train="1", name="n", frm=f, to=t, dep=Harness.D, arr=Harness.A)]
            def get_availability(s, *a): return {"status": "AVAILABLE-2", "fare": 100}
        p = Live(); r = run_checks(p, "A", "B", "2026-12-01"); self.assertTrue(all(c["schema_valid"] for c in r["checks"].values())); self.assertEqual(p.capabilities, {})
        class Bad(Live):
            def get_availability(s, *a): raise TimeoutError()
        r = run_checks(Bad(), "A", "B", "2026-12-01"); self.assertEqual(r["checks"]["get_availability"]["error"], "TimeoutError")
    def test_registry_lists_only_existing_adapters(self):
        from tools.verify_provider import REGISTRY; self.assertEqual(set(REGISTRY), {"railcore"})  # adapter exists; says nothing about verification
if __name__ == "__main__": unittest.main()
