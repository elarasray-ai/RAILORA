"""Deployment-facing behaviour: access gate, live-check endpoint, threaded server, stations, routes=off, Dockerfile guard. MOCKED provider only."""
import unittest, sys, os, json, io, threading, urllib.request
from socketserver import ThreadingMixIn
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from service import *
from api import make_app, make_threaded_server
from providers.demo import DemoProvider
from test_railcore import Base, MH, KEY
CODE = "correct-horse-1"; P = {"from": "JNU", "to": "LTT", "date": "2026-12-01", "pax": 1, "cls": "3A", "budget": 5000}
def call(app, path, method="GET", body=None, hdr=None, raw_out=False):
    raw = json.dumps(body).encode() if body is not None else b""; st = {}
    env = {"PATH_INFO": path, "REQUEST_METHOD": method, "QUERY_STRING": "", "REMOTE_ADDR": "1.1.1.1", "CONTENT_TYPE": "application/json", "CONTENT_LENGTH": str(len(raw)), "wsgi.input": io.BytesIO(raw), **(hdr or {})}
    out = b"".join(app(env, lambda s, h: st.update(s=int(s[:3])))); return st["s"], (out.decode() if raw_out else json.loads(out))
OK = {"HTTP_X_ACCESS_CODE": CODE}
class Gate(Base):
    def app(self, code=CODE, mode="production", **kw):
        a = make_app(Config(mode, routes="off"), providers=[self.prov()] if mode == "production" else [DemoProvider()], access_code=code, **kw); self.addCleanup(a.close); return a
    def test_no_code_configured_blocks_search_before_any_request(self):
        MH.trains = [("12656", {})]; s, j = call(self.app(code=""), "/api/search", "POST", P); self.assertEqual((s, j["error"]["code"], MH.log), (503, "ACCESS_CODE_NOT_SET", []))
    def test_wrong_or_missing_code(self):
        a = self.app()
        for h in (None, {"HTTP_X_ACCESS_CODE": "nope"}, {"HTTP_X_ACCESS_CODE": ""}): self.assertEqual(call(a, "/api/search", "POST", P, h)[0], 401)
        self.assertEqual(MH.log, []); MH.trains = [("12656", {})]; self.assertEqual(call(a, "/api/search", "POST", P, OK)[0], 200)
    def test_wrong_attempts_limited(self):
        a = self.app(); codes = [call(a, "/api/search", "POST", P, {"HTTP_X_ACCESS_CODE": f"bad{i}"})[0] for i in range(12)]
        self.assertEqual(codes, [401] * 10 + [429] * 2)
    def test_read_only_routes_not_gated(self):
        a = self.app(); self.assertEqual(call(a, "/health")[0], 200); self.assertEqual(call(a, "/api/nearby", "GET")[0], 400)
    def test_demo_mode_not_gated(self): self.assertEqual(call(self.app(code="", mode="demo"), "/api/search", "POST", P)[0], 200)
    def test_short_code_rejected(self):
        with self.assertRaises(ValueError): make_app(Config("demo"), access_code="short")
class Verify(Base):
    def app(self, t=None, **kw):
        a = make_app(Config("production"), providers=[self.prov(verified_ops="")], access_code=CODE, clock=(lambda: t[0]) if t else (lambda: 1000.0),
                     verify_factory=lambda: self.prov(verified_ops=""), **kw); self.addCleanup(a.close); return a
    B = {"frm": "JNU", "to": "LTT", "date": "2026-12-01"}
    def test_demo_mode_has_no_admin(self): self.assertEqual(call(make_app(Config("demo"), providers=[DemoProvider()], access_code=""), "/api/admin/verify", "POST", self.B)[0], 404)
    def test_requires_code(self): self.assertEqual(call(self.app(), "/api/admin/verify", "POST", self.B)[0], 401); self.assertEqual(MH.log, [])
    def test_report_has_evidence_and_enables_nothing(self):
        MH.trains = [("12656", {})]; s, j = call(self.app(), "/api/admin/verify", "POST", self.B, OK); self.assertEqual(s, 200)
        c = j["checks"]; self.assertTrue(c["trains_between"]["schema_valid"] and c["get_availability"]["schema_valid"])
        self.assertEqual((c["trains_between"]["sample"]["count"], c["get_availability"]["sample"]["status"], c["get_availability"]["sample"]["live"]), (1, "AVAILABLE-4", True))
        self.assertEqual(j["capabilities_enabled"], []); self.assertNotIn(KEY, json.dumps(j)); self.assertEqual(len(MH.log), 2)
    def test_failure_reported_safely(self):
        s, j = call(self.app(), "/api/admin/verify", "POST", dict(self.B, date="2026-12-31"), OK)
        self.assertEqual(s, 200); t = j["checks"]["trains_between"]; self.assertEqual((t["schema_valid"], t["error"], t["message"]), (False, "ProviderAuthError", "Provider rejected the credentials.")); self.assertNotIn(KEY, json.dumps(j))
    def test_cooldown(self):
        t = [1000.0]; a = self.app(t); MH.trains = [("12656", {})]
        self.assertEqual(call(a, "/api/admin/verify", "POST", self.B, OK)[0], 200); self.assertEqual(call(a, "/api/admin/verify", "POST", self.B, OK)[0], 429)
        t[0] += 31; self.assertEqual(call(a, "/api/admin/verify", "POST", self.B, OK)[0], 200)
    def test_rejects_unknown_fields(self): self.assertEqual(call(self.app(), "/api/admin/verify", "POST", {"evil": "x"}, OK)[0], 400)
    def test_default_inputs_are_documented_sample(self):
        MH.trains = []; call(self.app(), "/api/admin/verify", "POST", {}, OK); self.assertEqual({k: MH.log[0][1][k] for k in ("from", "to")}, {"from": "BSL", "to": "ADI"})
class Pages(unittest.TestCase):
    def test_pages(self):
        a = make_app(Config("production"), providers=[], access_code=CODE); self.addCleanup(a.close)
        s, h = call(a, "/", raw_out=True); self.assertEqual(s, 200); self.assertIn('window.RAILORA_MODE="production"', h); self.assertIn("RAILORA_API=location.origin", h)
        s, v = call(a, "/verify", raw_out=True); self.assertIn("X-Access-Code", v); self.assertNotIn(CODE, v)
class Server(unittest.TestCase):
    def test_threaded_and_concurrent(self):
        a = make_app(Config("demo"), providers=[DemoProvider()]); srv = make_threaded_server("127.0.0.1", 0, a); self.assertIsInstance(srv, ThreadingMixIn)
        th = threading.Thread(target=srv.serve_forever, daemon=True); th.start(); res = []
        def hit():
            with urllib.request.urlopen(f"http://127.0.0.1:{srv.server_port}/health") as r: res.append(r.status)
        ts = [threading.Thread(target=hit) for _ in range(8)]; [t.start() for t in ts]; [t.join(10) for t in ts]
        srv.shutdown(); srv.server_close(); th.join(5); a.close(); self.assertEqual(res, [200] * 8)
    def test_db_thread_safety(self):
        db = StationDB(); errs = []
        def w():
            try: [db.search("Mum") and db.nearby("LTT") and db.get("JNU") for _ in range(50)]
            except Exception as e: errs.append(e)
        ts = [threading.Thread(target=w) for _ in range(8)]; [t.start() for t in ts]; [t.join(10) for t in ts]; db.close(); self.assertEqual(errs, [])
class Misc(unittest.TestCase):
    def test_new_stations_searchable(self):
        with StationDB() as db:
            for q, code in (("Bhusaval", "BSL"), ("Ahmedabad", "ADI"), ("Delhi", "NDLS"), ("Calcutta", "HWH"), ("Bangalore", "SBC")): self.assertTrue(any(s["code"] == code for s in db.search(q)), q)
    def test_routes_off_is_direct_only(self):
        with SearchService(StationDB(), [DemoProvider()], Config("demo", routes="off")) as s: r = s.search(P)
        self.assertEqual((r["provider_calls"], r["dates"][0]["routes"], [x["train"] for x in r["dates"][0]["direct"]]), (3, [], ["90001"] if False else ["90001"]))
    def rd(self, name):
        with open(os.path.join(os.path.dirname(__file__), "..", "..", "deploy", "render", name), encoding="utf-8") as f: return f.read()
    def test_dockerfile_guard(self):
        d = self.rd("Dockerfile")
        for need in ("HOST=0.0.0.0", "PORT=10000", "RAILORA_MODE=production", "ROUTES_MODE=off", "USER user", "-u 1000", "glob", "test -f /app/railora/backend/api.py"): self.assertIn(need, d)
        for bad in ("RAILCORE_API_KEY=", "RAILORA_ACCESS_CODE=", "RAILCORE_VERIFIED_OPS", "7860"): self.assertNotIn(bad, d)
        self.assertEqual([l for l in d.splitlines() if l.strip().startswith("ARG")], [])  # Render turns env vars into build args: never declare one
    def test_render_yaml_guard(self):
        y = self.rd("render.yaml")
        for need in ("plan: free", "runtime: docker", "healthCheckPath: /health", "key: RAILCORE_API_KEY", "key: RAILORA_ACCESS_CODE"): self.assertIn(need, y)
        self.assertEqual(y.count("sync: false"), 2); self.assertNotIn("value:", y); self.assertNotIn("RAILCORE_VERIFIED_OPS", y)
    def test_bind_address(self):
        from api import bind_address
        self.assertEqual(bind_address({}), ("127.0.0.1", 10000)); self.assertEqual(bind_address({"RENDER": "true"}), ("0.0.0.0", 10000))
        self.assertEqual(bind_address({"HOST": "0.0.0.0", "PORT": "8123"}), ("0.0.0.0", 8123)); self.assertEqual(bind_address({"RENDER": "true", "PORT": "10000", "HOST": ""}), ("0.0.0.0", 10000))
if __name__ == "__main__": unittest.main()
