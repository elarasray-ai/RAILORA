import unittest, sys, os
from datetime import datetime as D, timedelta
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from engine import *
from providers.interface import Registry, RailCore, NotConfigured
T = D(2026,12,1,12,0)
def rec(s): return dict(status=s, verified=True, checked_at=T)
def leg(tr, f, t, dep, arr, fare, ok=True): return dict(train=tr, frm=f, to=t, dep=dep, arr=arr, fare=fare, ok=ok)
class Stations(unittest.TestCase):
    def test_aliases(self):
        for q in ("Bombay","LTT","Lokmanya","Mumbai"): self.assertTrue(any(s["code"]=="LTT" for s in search_stations(q)), q)
    def test_ambiguous_returns_many(self): self.assertGreater(len(search_stations("Mumbai")), 1)
    def test_banaras(self): self.assertEqual(search_stations("Banaras")[0]["code"], "BSB")
    def test_empty(self): self.assertEqual(search_stations("  "), [])
class Availability(unittest.TestCase):
    def test_parse(self):
        self.assertEqual(parse_status("AVAILABLE-0005"), ("AVAILABLE",5)); self.assertEqual(parse_status("GNWL3"), ("WL",3))
        self.assertEqual(parse_status("RAC 4")[0], "RAC"); self.assertEqual(parse_status("???")[0], "UNKNOWN")
    def test_confirmed_default(self): self.assertTrue(is_displayable(rec("AVAILABLE-5"))[0])
    def test_wl_hidden_by_default(self): self.assertFalse(is_displayable(rec("GNWL2"))[0])
    def test_wl1_5(self):
        for n in range(1,6): self.assertTrue(is_displayable(rec(f"WL{n}"), include_wl=True)[0])
    def test_wl6_rejected(self): self.assertFalse(is_displayable(rec("WL6"), include_wl=True)[0])
    def test_rac_regret_na_rejected(self):
        for s in ("RAC 3","REGRET","NOT AVAILABLE"): self.assertFalse(is_displayable(rec(s), include_wl=True)[0])
    def test_passenger_count(self):
        self.assertFalse(is_displayable(rec("AVAILABLE-2"), pax=3)[0]); self.assertTrue(is_displayable(rec("AVAILABLE-3"), pax=3)[0])
    def test_unknown_count_multi_pax(self): self.assertFalse(is_displayable(rec("AVAILABLE"), pax=2)[0])
    def test_unverified(self): self.assertFalse(is_displayable(dict(status="AVAILABLE-5", verified=False, checked_at=T))[0])
    def test_stale(self): self.assertEqual(is_displayable(rec("AVAILABLE-5"), now=T+timedelta(minutes=6))[1], "stale")
    def test_fresh(self): self.assertTrue(is_displayable(rec("AVAILABLE-5"), now=T+timedelta(minutes=2))[0])
    def test_class_and_date_independent(self):
        d = {("12-01","SL"):rec("AVAILABLE-5"), ("12-02","SL"):rec("REGRET"), ("12-01","3A"):rec("WL9")}
        self.assertEqual([is_displayable(v, include_wl=True)[0] for v in d.values()], [True, False, False])
class Failures(unittest.TestCase):
    def test_api_failure_is_error_not_unavailable(self):
        def boom(**k): raise TimeoutError()
        r = safe_availability(boom); self.assertEqual(r["error"], "TimeoutError"); self.assertIsNone(r["status"])
        self.assertEqual(is_displayable(r)[1], "provider_error")
    def test_unconfigured_provider(self):
        with self.assertRaises(NotConfigured): RailCore().get_availability()
        with self.assertRaises(NotConfigured): Registry([RailCore()]).pick("get_availability")
    def test_cache_ttl(self):
        t = [T]; c = TTLCache(60, lambda: t[0]); c.set("k", 1); self.assertEqual(c.get("k"), 1)
        t[0] = T + timedelta(seconds=61); self.assertIsNone(c.get("k"))
class Fare(unittest.TestCase):
    def test_sum(self): self.assertEqual(total_fare(320, 410), 730)
    def test_unknown_fare(self): self.assertIsNone(total_fare(320, None))
class Routes(unittest.TestCase):
    A = leg("A","JNU","PRYJ",D(2026,12,1,8),D(2026,12,1,12),320)
    def go(self, b, **k): return find_connections([self.A, b], "JNU", {"LTT"}, k.pop("budget",800), **k)
    def test_valid(self):
        r = self.go(leg("B","PRYJ","LTT",D(2026,12,1,14),D(2026,12,2,6),410)); self.assertEqual((r[0]["fare"], r[0]["wait_min"]), (730, 120))
    def test_overnight(self):
        b = leg("B","PRYJ","LTT",D(2026,12,2,1),D(2026,12,2,20),410)
        self.assertEqual(self.go(b), []); self.assertEqual(self.go(b, max_wait=900)[0]["wait_min"], 780)
    def test_departs_before_arrival(self): self.assertEqual(self.go(leg("B","PRYJ","LTT",D(2026,12,1,11),D(2026,12,2,6),410)), [])
    def test_buffer_too_short(self): self.assertEqual(self.go(leg("B","PRYJ","LTT",D(2026,12,1,12,30),D(2026,12,2,6),410)), [])
    def test_over_budget(self): self.assertEqual(self.go(leg("B","PRYJ","LTT",D(2026,12,1,14),D(2026,12,2,6),500)), [])
    def test_unknown_fare_rejected(self): self.assertEqual(self.go(leg("B","PRYJ","LTT",D(2026,12,1,14),D(2026,12,2,6),None)), [])
    def test_unavailable_leg(self): self.assertEqual(self.go(leg("B","PRYJ","LTT",D(2026,12,1,14),D(2026,12,2,6),410,ok=False)), [])
    def test_station_change_needs_extra_time(self):
        a = leg("A","JNU","ZNP",D(2026,12,1,8),D(2026,12,1,12),320); b = leg("B","BSB","LTT",D(2026,12,1,13,30),D(2026,12,2,6),410)
        tr = {("ZNP","BSB"):60}
        self.assertEqual(find_connections([a,b],"JNU",{"LTT"},800,transfer=tr), [])
        b["dep"] = D(2026,12,1,14,30); self.assertEqual(len(find_connections([a,b],"JNU",{"LTT"},800,transfer=tr)), 1)
        self.assertEqual(find_connections([a,b],"JNU",{"LTT"},800), [])
    def test_never_three_tickets_and_max_two_results(self):
        c = leg("C","LTT","CSMT",D(2026,12,2,8),D(2026,12,2,9),50)
        r = find_connections([self.A, leg("B","PRYJ","BSB",D(2026,12,1,14),D(2026,12,1,18),100), c], "JNU", {"CSMT"}, 9999)
        self.assertEqual(r, [])
        bs = [leg(f"B{i}","PRYJ","LTT",D(2026,12,1,14+i),D(2026,12,2,6),400+i) for i in range(4)]
        self.assertEqual(len(find_connections([self.A]+bs,"JNU",{"LTT"},9999)), 2)
class Nearby(unittest.TestCase):
    def test_rank(self):
        r = nearby([{"code":"X","km":5,"trains":2},{"code":"PRYJ","km":80,"trains":40},{"code":"FAR","km":500,"trains":99}])
        self.assertEqual([c["code"] for c in r], ["PRYJ","X"])
if __name__ == "__main__": unittest.main()
