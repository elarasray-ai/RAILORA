import unittest, sys, os, json, tempfile, threading, sqlite3, importlib.util, urllib.request, urllib.error
from datetime import datetime, timezone, timedelta
from wsgiref.simple_server import make_server, WSGIRequestHandler
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from service import *
from engine import STATIONS
from api import make_app
from providers.demo import DemoProvider
P = dict(**{"from": "JNU", "to": "LTT"}, date="2026-12-01", pax=1, cls="3A", budget=1000)
class Migration(unittest.TestCase):
    def test_init_and_idempotent(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "r.db"); db = StationDB(path); db.c.close()
            db2 = StationDB(path)  # reopen: no re-seed, no duplicates
            self.assertEqual(db2.c.execute("SELECT count(*) FROM stations").fetchone()[0], len(STATIONS))
            names = {r[0] for r in db2.c.execute("SELECT name FROM sqlite_master WHERE type IN ('table','index')")}
            self.assertTrue({"stations", "aliases", "ix_alias"} <= names)
            with open(os.path.join(os.path.dirname(__file__), "..", "migrations", "001_stations.sql"), encoding="utf-8") as f: db2.c.executescript(f.read())  # re-run safe
            db2.close()
    def test_persisted_file_search(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "r.db"); StationDB(p).c.close(); self.assertEqual(StationDB(p).search("Bombay")[0]["city"], "Mumbai")
class Cfg(unittest.TestCase):
    def test_defaults_and_env(self):
        os.environ.pop("AVAILABILITY_TTL_SECONDS", None); os.environ.pop("RAILORA_MODE", None)
        c = Config.from_env(); self.assertEqual((c.mode, c.ttl), ("demo", 60))
        os.environ.update(AVAILABILITY_TTL_SECONDS="30", RAILORA_MODE="production")
        try: c = Config.from_env(); self.assertEqual((c.mode, c.ttl), ("production", 30))
        finally: os.environ.pop("AVAILABILITY_TTL_SECONDS"); os.environ.pop("RAILORA_MODE")
    def test_invalid(self):
        for kw in (dict(ttl=0), dict(ttl=301), dict(mode="live")):
            with self.assertRaises(ValueError): Config(**kw)
class Cache(unittest.TestCase):
    def test_cached_flag_original_timestamp_source(self):
        t = [datetime(2026, 12, 1, tzinfo=timezone.utc)]; s = SearchService(StationDB(), [DemoProvider()], Config(), lambda: t[0])
        a = s.search(P)["dates"][0]["direct"][0]; self.assertFalse(a["cached"]); self.assertEqual((a["age_seconds"], a["source"]), (0, "demo"))
        t[0] += timedelta(seconds=40); b = s.search(P)["dates"][0]["direct"][0]
        self.assertTrue(b["cached"]); self.assertEqual((b["checked_at"], b["age_seconds"]), (a["checked_at"], 40))
        t[0] += timedelta(seconds=21); c = s.search(P)["dates"][0]["direct"][0]  # 61s > ttl 60: refetched
        self.assertFalse(c["cached"]); self.assertGreater(c["checked_at"], a["checked_at"])
class Search(unittest.TestCase):
    def s(self): return SearchService(StationDB(), [DemoProvider()], Config())
    def test_nearby_selection(self):
        r = self.s().search(dict(P, nearby=True, nearby_codes=["ZNP"]))["nearby"]; self.assertEqual([x["code"] for x in r["from"]], ["ZNP"])
        self.assertEqual(self.s().search(dict(P, nearby=True, nearby_codes=[]))["nearby"]["from"], [])
    def test_date_range_limit(self):
        ds = [f"2026-12-{i:02d}" for i in range(1, 8)]; self.assertEqual(len(self.s().search(dict(P, dates=ds))["dates"]), 7)
        with self.assertRaises(ServiceError): self.s().search(dict(P, dates=ds + ["2026-12-08"]))
class Quiet(WSGIRequestHandler):
    def log_message(self, *a): pass
class RealServer(unittest.TestCase):
    def test_http_roundtrip(self):
        srv = make_server("127.0.0.1", 0, make_app(Config()), handler_class=Quiet); base = f"http://127.0.0.1:{srv.server_port}"
        th = threading.Thread(target=lambda: [srv.handle_request() for _ in range(4)]); th.start()
        try:
            self.assertEqual(json.load(urllib.request.urlopen(base + "/health"))["status"], "ok")
            with urllib.request.urlopen(base + "/") as r: page = r.read().decode(); self.assertIn("window.RAILORA_API=location.origin", page); self.assertIn("RAILORA", page)
            req = urllib.request.Request(base + "/api/search", json.dumps(P).encode(), {"Content-Type": "application/json"})
            self.assertEqual(json.load(urllib.request.urlopen(req))["data_source"], "DEMO")
            with self.assertRaises(urllib.error.HTTPError) as e: urllib.request.urlopen(base + "/missing")
            self.assertEqual(e.exception.code, 404)
        finally: th.join(5); srv.server_close()
@unittest.skipUnless(importlib.util.find_spec("fastapi"), "fastapi not installed: wrapper UNVERIFIED")
class FastApiWrapper(unittest.TestCase):
    def test_mounts(self):
        import fastapi_app; self.assertTrue(fastapi_app.app.routes)
if __name__ == "__main__": unittest.main()
