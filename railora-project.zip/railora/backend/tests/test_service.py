import unittest, sys, os, json, io
from datetime import datetime, timezone, timedelta
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from service import *
from api import make_app, RateLimiter
from providers.demo import DemoProvider
from providers.interface import Provider
def svc(mode="demo", prov=None, clock=None):
    return SearchService(StationDB(), [prov or DemoProvider()], Config(mode, max_calls=1000), *( [clock] if clock else []))
P = dict(**{"from": "JNU", "to": "LTT"}, date="2026-12-01", pax=1, cls="3A", budget=1000)
class Db(unittest.TestCase):
    db = StationDB()
    def test_alias(self): self.assertEqual(self.db.search("Banaras")[0]["code"], "BSB")
    def test_ambiguous(self): self.assertGreater(len(self.db.search("Mumbai")), 1)
    def test_short(self): self.assertEqual(self.db.search("a"), [])
    def test_nearby(self):
        n = self.db.nearby("JNU"); self.assertEqual(n[0]["code"], "ZNP"); self.assertTrue(all(x["extra_km"] <= 60 for x in n))
        self.assertIn("CSMT", [x["code"] for x in self.db.nearby("LTT", limit=6)])
class Modes(unittest.TestCase):
    def test_production_refuses_demo(self):
        with self.assertRaises(ServiceError) as c: svc("production").search(P)
        self.assertEqual(c.exception.code, "NO_VERIFIED_PROVIDER")
    def test_demo_labelled(self): self.assertEqual(svc().search(P)["data_source"], "DEMO")
    def test_bad_mode(self):
        with self.assertRaises(ValueError): Config("live")
class Search(unittest.TestCase):
    def test_direct_confirmed_only(self):
        d = svc().search(P)["dates"][0]; self.assertEqual([x["train"] for x in d["direct"]], ["90001"]); self.assertEqual(d["direct"][0]["fare"], 820)
    def test_wl_option(self):
        d = svc().search(dict(P, cls="SL", wl=True))["dates"][0]; self.assertEqual([x["train"] for x in d["direct"]], ["90001"])
        self.assertEqual(svc().search(dict(P, cls="SL"))["dates"][0]["direct"], [])
    def test_pax_and_fare_multiplied(self):
        self.assertEqual(svc().search(dict(P, pax=5, budget=9999))["dates"][0]["direct"], [])
        self.assertEqual(svc().search(dict(P, pax=2, budget=9999))["dates"][0]["direct"][0]["fare"], 1640)
    def test_routes(self):
        r = svc().search(P)["dates"][0]["routes"]; self.assertLessEqual(len(r), 2); self.assertTrue(all(x["separate_tickets"] and len(x["legs"]) == 2 for x in r))
        self.assertEqual(r[0]["fare"], 720); self.assertEqual(svc().search(dict(P, budget=500))["dates"][0]["routes"], [])
    def test_datewise_partial(self):
        r = svc().search(dict(P, dates=["2026-12-01", "2026-12-02", "2026-12-09"]))
        self.assertEqual([bool(d["error"]) for d in r["dates"]], [False, True, False][:0] or [False, False, True]); self.assertFalse(r["complete"])
        self.assertEqual(r["dates"][1]["direct"], []); self.assertTrue(r["dates"][1]["routes"])  # date 2 independent: connection only
    def test_nearby_flag(self): self.assertIn("nearby", svc().search(dict(P, nearby=True)))
    def test_validation(self):
        for bad in (dict(P, pax=9), dict(P, cls="XX"), dict(P, date="nope"), {"from": "JNU"}, dict(P, to="JNU"), dict(P, to="ZZZ")):
            with self.assertRaises(ServiceError): svc().search(bad)
class Failures(unittest.TestCase):
    class Broken(DemoProvider):
        def get_availability(self, *a): raise TimeoutError()
    def test_failure_not_unavailable(self):
        d = svc(prov=self.Broken()).search(P)["dates"][0]; self.assertEqual(d["direct"], []); self.assertTrue(d["errors"])
    def test_failure_marks_incomplete(self): self.assertFalse(svc(prov=self.Broken()).search(P)["complete"])
    def test_cache_and_stale(self):
        t = [datetime(2026, 12, 1, tzinfo=timezone.utc)]; s = svc(clock=lambda: t[0]); s.search(P); n = len(s.cache); k = next(iter(s.cache))
        t0 = s.cache[k]["checked_at"]; s.search(P); self.assertEqual(s.cache[k]["checked_at"], t0)
        t[0] += timedelta(seconds=301); s.search(P); self.assertGreater(s.cache[k]["checked_at"], t0)
    def test_no_provider_capability(self):
        with self.assertRaises(ServiceError): SearchService(StationDB(), [Provider()], Config()).search(P)
class Api(unittest.TestCase):
    def call(self, app, path, method="GET", body=None, qs="", hdr=None):
        raw = json.dumps(body).encode() if body is not None else b""; st = {}
        env = dict(PATH_INFO=path, REQUEST_METHOD=method, QUERY_STRING=qs, CONTENT_TYPE="application/json", CONTENT_LENGTH=str(len(raw)), REMOTE_ADDR="1.1.1.1", **{"wsgi.input": io.BytesIO(raw), **(hdr or {})})
        res = b"".join(app(env, lambda s, h: st.update(s=int(s[:3]))))
        return st["s"], json.loads(res)
    def test_health(self): self.assertEqual(self.call(make_app(Config()), "/health")[1]["status"], "ok")
    def test_stations(self): self.assertTrue(self.call(make_app(Config()), "/api/stations", qs="q=bombay")[1]["stations"])
    def test_search(self): s, j = self.call(make_app(Config()), "/api/search", "POST", P); self.assertEqual((s, j["data_source"]), (200, "DEMO"))
    def test_errors_sanitized(self):
        a = make_app(Config("production"), providers=[DemoProvider()], access_code="correct-horse-1"); s, j = self.call(a, "/api/search", "POST", P, hdr={"HTTP_X_ACCESS_CODE": "correct-horse-1"}); self.assertEqual((s, j["error"]["code"]), (503, "NO_VERIFIED_PROVIDER"))
        self.assertEqual(self.call(make_app(Config()), "/api/search", "POST", {"from": "JNU"})[0], 400)
        class Boom(DemoProvider):
            def trains_between(self, *a): raise RuntimeError("secret-key-123")
        s, j = self.call(make_app(Config(), providers=[Boom()]), "/api/search", "POST", P); self.assertNotIn("secret", json.dumps(j))
    def test_rate_limit(self):
        a = make_app(Config(), limiter=RateLimiter(2)); [self.call(a, "/health") for _ in range(2)]; self.assertEqual(self.call(a, "/health")[0], 429)
    def test_404(self): self.assertEqual(self.call(make_app(Config()), "/nope")[0], 404)
if __name__ == "__main__": unittest.main()
