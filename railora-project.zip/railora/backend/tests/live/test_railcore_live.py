"""LIVE tests: call the real RailCore API. NOT part of the default suite (live/ is not a package, so discovery skips it).
Each test costs 1 request of your allowance (the Free tier is documented as 500/month). Run only on a trusted server:
    export RAILCORE_API_KEY=...   # from your secret store, never from chat or Git
    RAILORA_LIVE_TESTS=1 python3 -m unittest discover -s backend/tests/live -v
Optional: RAILCORE_LIVE_TRAIN (default 12656), RAILCORE_LIVE_FROM (BSL), RAILCORE_LIVE_TO (ADI), RAILCORE_LIVE_CLASS (3A). Date = today + 7 days."""
import unittest, sys, os
from datetime import date, timedelta
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
from engine import parse_status
from providers.railcore import RailCoreProvider
from tools.verify_provider import validate_normalized
LIVE = os.environ.get("RAILORA_LIVE_TESTS") == "1" and bool(os.environ.get("RAILCORE_API_KEY"))
E = os.environ.get
@unittest.skipUnless(LIVE, "live tests disabled: set RAILORA_LIVE_TESTS=1 and RAILCORE_API_KEY")
class RailCoreLive(unittest.TestCase):
    d = (date.today() + timedelta(days=7)).isoformat(); a = (E("RAILCORE_LIVE_FROM", "BSL"), E("RAILCORE_LIVE_TO", "ADI"))
    def test_availability_live(self):
        r = RailCoreProvider().get_availability(E("RAILCORE_LIVE_TRAIN", "12656"), *self.a, self.d, E("RAILCORE_LIVE_CLASS", "3A"), "GN")
        self.assertTrue(validate_normalized("availability", r)); self.assertEqual((r["source"], r["live"]), ("railcore", True)); self.assertNotEqual(parse_status(r["status"])[0], "UNKNOWN")
        self.assertIsNotNone(r["retrieved_at"]); print("\nlive availability:", r["status"], r["fare"], r["provider_updated_at"])
    def test_trains_between_live(self):
        r = RailCoreProvider().trains_between(*self.a, self.d); self.assertTrue(r); self.assertTrue(all(validate_normalized("train", t) for t in r)); print("\nlive trains:", len(r), "dropped:", 0)
if __name__ == "__main__": unittest.main()
