"""MOCKED tests for the RailCore adapter. A local fake server returns responses shaped like RailCore's published examples.
These tests prove parsing/handling logic only. They do NOT prove RailCore behaves this way: see tests/live/ for real-API tests."""
import unittest, sys, os, json, io, threading, time, http.server
from datetime import datetime, timezone, timedelta
from urllib.parse import urlparse, parse_qs
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from service import *
from api import make_app
from engine import is_displayable
from providers.demo import DemoProvider
from providers.interface import *
from providers.railcore import RailCoreProvider, normalize_status, IST
CLOCK = datetime(2026, 11, 14, 3, 44, tzinfo=timezone.utc); KEY = "TESTKEY-0123456789abcdef"; T = datetime(2026, 12, 1, tzinfo=timezone.utc)
def entry(**o):
    e = {"class_code": "3A", "status": "AVAILABLE", "availability_text": "AVAILABLE-4", "available_count": 4, "waitlist_count": 0, "rac_count": 0, "fare": 965, "catering_charge": 0,
         "total_fare": 965, "confirmation_probability": {"percentage": 100, "label": "HIGH", "text": "Available"}, "last_updated_at": "2026-11-14T08:15:46.547+05:30"}
    e.update(o); return e
def avail(q, e, meta=None, **data):
    d = {"train_number": q["train_number"], "from_station_code": q["from"], "to_station_code": q["to"], "journey_date": q["date"], "quota": q.get("quota", "GN"), "classes": [e]}; d.update(data)
    m = {"api_version": "v1", "request_id": "req_mock", "timestamp": "2026-11-14T03:43:50.835Z", "freshness": {"mode": "live", "retrieved_at": "2026-11-14T03:43:50.835Z", "sources": [{"confidence": "high"}]}}
    m.update(meta or {}); return {"success": True, "data": d, "meta": m}
def err(code): return {"success": False, "error": {"code": code, "message": "mock"}}
ok = lambda b: (200, {}, b)
SC = {  # train_number -> fn(q) -> (http_status, extra_headers, body)
 "12656": lambda q: ok(avail(q, entry())),
 "20001": lambda q: ok(avail(q, entry(status="REGRET", availability_text="REGRET", available_count=0))),
 "20002": lambda q: ok(avail(q, entry(status="WAITLIST", availability_text="GNWL3", available_count=0, waitlist_count=3))),
 "20003": lambda q: ok(avail(q, entry(status="WAITLIST", availability_text="GNWL8", available_count=0, waitlist_count=8))),
 "20004": lambda q: ok(avail(q, entry(status="RAC", availability_text="RAC2", available_count=0, rac_count=2))),
 "20005": lambda q: ok(avail(q, entry(status="NOT_AVAILABLE", available_count=0))),
 "20006": lambda q: ok(avail(q, entry(status="REGRET", availability_text="REGRET", available_count=5))),  # contradictory: REGRET must win
 "20007": lambda q: ok(avail(q, entry(availability_text="AVAILABLE-9"))),
 "20008": lambda q: ok(avail(q, entry(availability_text="AVAILABLE", available_count=None))),
 "20009": lambda q: ok(avail(q, entry(status="SOMETHING_NEW"))),
 "20010": lambda q: ok(avail(q, entry(status="TRAIN_CANCELLED", available_count=0))),
 "20011": lambda q: ok(avail(q, entry(), meta={"freshness": {"mode": "cached"}})),
 "20012": lambda q: ok(avail(q, entry(last_updated_at="2026-11-13T01:00:00+05:30"))),
 "20013": lambda q: (200, {}, {"success": False}),
 "20014": lambda q: ok(avail(q, entry(), train_number="99999")),
 "20015": lambda q: ok(avail(q, entry(class_code="SL"))),
 "20016": lambda q: (422, {}, err("CLASS_NOT_AVAILABLE")), "20017": lambda q: (422, {}, err("TRAIN_NOT_RUNNING")), "20018": lambda q: (422, {}, err("BOOKING_NOT_OPEN")),
 "20028": lambda q: (422, {}, err("TATKAL_NOT_OPEN")), "20029": lambda q: (422, {}, err("QUOTA_NOT_AVAILABLE")),
 "20019": lambda q: (402, {}, err("CREDITS_EXHAUSTED")), "20020": lambda q: (401, {}, err("INVALID_API_KEY")), "20032": lambda q: (403, {}, err("SCOPE_MISSING")),
 "20021": lambda q: (429, {"Retry-After": "7"}, err("RATE_LIMITED")), "20022": lambda q: (503, {}, err("UPSTREAM_UNAVAILABLE")), "20033": lambda q: (400, {}, err("VALIDATION_ERROR")),
 "20024": lambda q: ok(avail(q, entry(total_fare=None))),
 "20025": lambda q: ok(avail(q, entry(status="WAITLIST", availability_text="GNWL12", available_count=0, waitlist_count=0))),
 "20026": lambda q: ok(avail(q, entry(available_count=0, availability_text="AVAILABLE"))),
 "20027": lambda q: ok(avail(q, entry(last_updated_at="yesterday"))),
}
def train(q, n, **o):
    t = {"train_number": n, "from_station_code": q["from"], "from_station_name": "Mock From", "to_station_code": q["to"], "to_station_name": "Mock To", "train_name": "MOCK EXP",
         "extended_train_name": "Mock Express", "departure_time": "10:25", "arrival_time": "18:00", "duration_minutes": 455, "classes": ["SL", "3A"], "running_days": ["MON"], "extra_unknown_field": 1}
    t.update(o); return t
class MH(http.server.BaseHTTPRequestHandler):
    lock = threading.Lock(); log = []; hits = {}; trains = []; flaky = 0
    def log_message(self, *a): pass
    def do_GET(self):
        u = urlparse(self.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}
        with MH.lock: MH.log.append((u.path, q, {k.lower(): v for k, v in self.headers.items()})); k = q.get("train_number", u.path); MH.hits[k] = MH.hits.get(k, 0) + 1; n = MH.hits[k]
        code, hdr, body = 404, {}, err("NOT_FOUND")
        if u.path == "/v1/availability/seats":
            tn = q.get("train_number")
            if tn == "20030": time.sleep(0.5)
            if tn == "20031": code, hdr, body = ok(avail(q, entry())) if n >= 3 else (503, {}, err("UPSTREAM_UNAVAILABLE"))
            elif tn == "20023": self.send_response(200); self.send_header("Content-Length", "6"); self.end_headers(); self.wfile.write(b"<html>"); return
            elif tn in SC: code, hdr, body = SC[tn](q)
            else: code, hdr, body = ok(avail(q, entry()))
        elif u.path == "/v1/routes/trains":
            if q["date"] == "2026-12-31": code, hdr, body = 401, {}, err("INVALID_API_KEY")
            elif q["from"] == "XXX" or (q["from"], q["to"]) != ("JNU", "LTT") and q["from"] not in ("BAD", "WRG"): code, hdr, body = 404, {}, err("NO_TRAINS_FOUND")
            elif q["from"] == "BAD": code, hdr, body = ok({"success": True, "data": {"journey_date": q["date"], "trains": [{"train_number": "1"}]}})
            else: code, hdr, body = ok({"success": True, "data": {"from_station_code": q["from"], "to_station_code": q["to"], "journey_date": q.get("date") if q["from"] != "WRG" else "2020-01-01", "quota": "GN", "matched_by": "station", "trains": [train(q, n, **o) for n, o in MH.trains]}, "meta": {}})
        raw = json.dumps(body).encode()
        try:
            self.send_response(code)
            for h, v in hdr.items(): self.send_header(h, v)
            self.send_header("Content-Length", str(len(raw))); self.end_headers(); self.wfile.write(raw)
        except (BrokenPipeError, ConnectionResetError): pass  # client timed out on purpose
class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), MH); threading.Thread(target=cls.srv.serve_forever, daemon=True).start(); cls.url = f"http://127.0.0.1:{cls.srv.server_port}/v1"
    @classmethod
    def tearDownClass(cls): cls.srv.shutdown(); cls.srv.server_close()
    def setUp(self): MH.log.clear(); MH.hits.clear(); MH.trains = []; self.sl = []
    def prov(self, **kw): kw.setdefault("sleep", self.sl.append); kw.setdefault("verified_ops", "trains_between,get_availability"); return RailCoreProvider(api_key=kw.pop("api_key", KEY), base_url=self.url, **kw)
    def av(self, tn, p=None, **kw): return (p or self.prov(**kw)).get_availability(tn, "BSL", "ADI", "2026-11-21", "3A", "GN")
class Availability(Base):
    def test_exact_request(self):
        self.av("12656"); path, q, h = MH.log[-1]
        self.assertEqual(path, "/v1/availability/seats"); self.assertEqual(q, {"train_number": "12656", "from": "BSL", "to": "ADI", "date": "2026-11-21", "class": "3A", "quota": "GN"})
        self.assertEqual(h.get("x-railcore-key"), KEY); self.assertNotIn("authorization", h); self.assertNotIn("x-api-key", h)
    def test_normalized_success_and_timestamps(self):
        r = self.av("12656")
        self.assertEqual((r["status"], r["fare"], r["live"], r["freshness_mode"], r["source"], r["request_id"]), ("AVAILABLE-4", 965, True, "live", "railcore", "req_mock"))
        self.assertEqual(r["provider_updated_at"], datetime(2026, 11, 14, 8, 15, 46, 547000, tzinfo=IST)); self.assertEqual(r["retrieved_at"], datetime(2026, 11, 14, 3, 43, 50, 835000, tzinfo=timezone.utc))
        self.assertEqual(r["forecast"]["percentage"], 100); self.assertEqual(r["provider_status"], "AVAILABLE")
    def test_status_table(self):
        for tn, want in {"20001": "REGRET", "20002": "WL3", "20003": "WL8", "20004": "RAC 2", "20005": "NOT AVAILABLE", "20006": "REGRET", "20007": "UNKNOWN", "20008": "AVAILABLE",
                         "20009": "UNKNOWN", "20010": "TRAIN_CANCELLED", "20025": "WL12", "20026": "UNKNOWN"}.items(): self.assertEqual(self.av(tn)["status"], want, tn)
    def test_regret_never_confirmed(self):
        for tn in ("20001", "20006"):
            r = self.av(tn); self.assertFalse(is_displayable({"status": r["status"], "verified": r["live"], "checked_at": T}, include_wl=True)[0])
    def test_display_gating_end_to_end(self):
        rec = lambda tn: (lambda r: {"status": r["status"], "verified": r["live"], "checked_at": T})(self.av(tn))
        self.assertTrue(is_displayable(rec("12656"))[0]); self.assertFalse(is_displayable(rec("20002"))[0]); self.assertTrue(is_displayable(rec("20002"), include_wl=True)[0])
        for tn in ("20003", "20004", "20005", "20009", "20010", "20026"): self.assertFalse(is_displayable(rec(tn), include_wl=True)[0], tn)
        self.assertTrue(is_displayable(rec("20008"))[0]); self.assertFalse(is_displayable(rec("20008"), pax=2)[0])  # count unknown: never invent a seat count
    def test_not_live_flagged(self): r = self.av("20011"); self.assertEqual((r["live"], r["freshness_mode"]), (False, "cached"))
    def test_stale_timestamp_preserved(self): self.assertEqual(self.av("20012")["provider_updated_at"], datetime(2026, 11, 13, 1, 0, tzinfo=IST))
    def test_missing_fare_and_bad_timestamp(self): self.assertIsNone(self.av("20024")["fare"]); self.assertIsNone(self.av("20027")["provider_updated_at"])
    def test_invalid_responses(self):
        for tn in ("20013", "20014", "20015", "20023"):
            with self.assertRaises(ProviderBadResponse, msg=tn): self.av(tn)
    def test_not_offered_reasons(self):
        for tn, why in {"20016": "class_not_offered", "20017": "train_not_running", "20018": "booking_not_open", "20028": "tatkal_not_open", "20029": "quota_not_offered"}.items():
            with self.assertRaises(NotOffered) as c: self.av(tn)
            self.assertEqual(c.exception.reason, why); self.assertEqual(MH.hits[tn], 1)
    def test_provider_errors(self):
        for tn, exc in {"20019": ProviderQuotaExhausted, "20020": ProviderAuthError, "20032": ProviderAuthError, "20033": ProviderBadResponse}.items():
            with self.assertRaises(exc, msg=tn) as c: self.av(tn)
            self.assertEqual(MH.hits[tn], 1); self.assertNotIn(KEY, str(c.exception)); self.assertNotIn("127.0.0.1", str(c.exception))
    def test_rate_limit_honours_retry_after_without_retry(self):
        with self.assertRaises(ProviderRateLimited) as c: self.av("20021")
        self.assertEqual((c.exception.retry_after, MH.hits["20021"], self.sl), (7.0, 1, []))
    def test_upstream_unavailable_capped_retries(self):
        with self.assertRaises(ProviderUnavailable): self.av("20022")
        self.assertEqual(MH.hits["20022"], 3)
    def test_retry_then_success(self): self.assertEqual(self.av("20031")["status"], "AVAILABLE-4"); self.assertEqual((MH.hits["20031"], self.sl), (3, [0.5, 1.0]))
    def test_timeout(self):
        with self.assertRaises(ProviderUnavailable): self.av("20030", timeout=0.1, max_retries=0)
    def test_connection_refused(self):
        with self.assertRaises(ProviderUnavailable): RailCoreProvider(api_key=KEY, base_url="http://127.0.0.1:1/v1", sleep=lambda s: None, max_retries=0).get_availability("12656", "BSL", "ADI", "2026-11-21", "3A", "GN")
    def test_invalid_input_never_sent(self):
        for a in (("ab", "BSL", "ADI", "2026-11-21", "3A", "GN"), ("12656", "bsl", "ADI", "2026-11-21", "3A", "GN"), ("12656", "BSL", "ADI", "2026-1-1", "3A", "GN"),
                  ("12656", "BSL", "ADI", "2026-11-21", "ABCD", "GN"), ("12656", "BSL&x=1", "ADI", "2026-11-21", "3A", "GN"), ("12656", "BSL", "ADI", "2026-11-21", "3A", "gn")):
            with self.assertRaises(ProviderBadResponse): self.prov().get_availability(*a)
        self.assertEqual(MH.log, [])
class Credentials(Base):
    def test_missing_key_no_request(self):
        old = os.environ.pop("RAILCORE_API_KEY", None)
        try:
            p = RailCoreProvider(base_url=self.url, verified_ops="get_availability")
            with self.assertRaises(NotConfigured): p.get_availability("12656", "BSL", "ADI", "2026-11-21", "3A", "GN")
            with self.assertRaises(NotConfigured): p.trains_between("BSL", "ADI", "2026-11-21")
        finally:
            if old: os.environ["RAILCORE_API_KEY"] = old
        self.assertEqual(MH.log, [])
    def test_key_from_environment_only(self):
        os.environ["RAILCORE_API_KEY"] = "ENVKEY-9876543210"
        try: RailCoreProvider(base_url=self.url).get_availability("12656", "BSL", "ADI", "2026-11-21", "3A", "GN")
        finally: os.environ.pop("RAILCORE_API_KEY")
        self.assertEqual(MH.log[-1][2].get("x-railcore-key"), "ENVKEY-9876543210")
    def test_repr_hides_key(self): self.assertNotIn(KEY, repr(self.prov())); self.assertIn("set", repr(self.prov()))
    def test_capabilities_default_empty_and_gated(self):
        os.environ.pop("RAILCORE_VERIFIED_OPS", None); self.assertEqual(RailCoreProvider(api_key=KEY).capabilities, {})
        os.environ["RAILCORE_VERIFIED_OPS"] = "get_availability, get_fare ,bogus"
        try: self.assertEqual(RailCoreProvider(api_key=KEY).capabilities, {"get_availability": True})  # unimplemented/unknown ops ignored
        finally: os.environ.pop("RAILCORE_VERIFIED_OPS")
    def test_unimplemented_ops_not_configured(self):
        p = self.prov()
        for op in ("search_stations", "get_fare", "get_schedule", "search_trains", "get_running_status"):
            with self.assertRaises(NotConfigured): getattr(p, op)()
    def test_env_example_has_no_key_value(self):
        with open(os.path.join(os.path.dirname(__file__), "..", "..", ".env.example"), encoding="utf-8") as f: lines = [l.split("#")[0].strip() for l in f if l.startswith("RAILCORE_API_KEY")]
        self.assertEqual(lines, ["RAILCORE_API_KEY="])  # empty value; comments allowed
class TrainsBetween(Base):
    def tb(self, f="JNU", d="2026-12-01", **kw): return self.prov(**kw).trains_between(f, "LTT", d)
    def test_request_and_mapping(self):
        MH.trains = [("12656", {}), ("20099", {"departure_time": "22:00", "arrival_time": "08:00", "duration_minutes": 600})]
        r = self.tb(); path, q, h = MH.log[-1]; self.assertEqual((path, q), ("/v1/routes/trains", {"from": "JNU", "to": "LTT", "date": "2026-12-01", "match": "station"})); self.assertEqual(h["x-railcore-key"], KEY)
        a, b = r; self.assertEqual((a["train"], a["name"], a["frm"], a["to"], a["classes"]), ("12656", "MOCK EXP", "JNU", "LTT", ["SL", "3A"]))
        self.assertEqual((a["dep"], a["arr"]), (datetime(2026, 12, 1, 10, 25, tzinfo=IST), datetime(2026, 12, 1, 18, 0, tzinfo=IST)))
        self.assertEqual((b["dep"], b["arr"]), (datetime(2026, 12, 1, 22, 0, tzinfo=IST), datetime(2026, 12, 2, 8, 0, tzinfo=IST)))  # overnight
    def test_no_trains_is_empty_not_error(self): self.assertEqual(self.tb("XXX"), [])
    def test_malformed_record_rejected(self):
        with self.assertRaises(ProviderBadResponse): self.tb("BAD")
    def test_journey_date_mismatch_rejected(self):
        with self.assertRaises(ProviderBadResponse): self.tb("WRG")
    def test_inconsistent_records_dropped_not_invented(self):
        MH.trains = [("30001", {"arrival_time": "19:00"}), ("30002", {"from_station_code": "ZZZ"}), ("30003", {})]; p = self.prov(); r = p.trains_between("JNU", "LTT", "2026-12-01")
        self.assertEqual(([x["train"] for x in r], p.dropped), (["30003"], 2))
    def test_classes_absent_means_unknown(self):
        MH.trains = [("30004", {"classes": None})]; self.assertNotIn("classes", self.tb()[0])
    def test_auth_error(self):
        with self.assertRaises(ProviderAuthError): self.tb(d="2026-12-31")
    def test_invalid_input_never_sent(self):
        with self.assertRaises(ProviderBadResponse): self.prov().trains_between("jnu", "LTT", "2026-12-01")
        self.assertEqual(MH.log, [])
class ServiceWithMock(Base):
    P = {"from": "JNU", "to": "LTT", "date": "2026-12-01", "pax": 1, "cls": "3A", "budget": 5000}
    def svc(self, mode="production", ops="trains_between,get_availability", **cfg):
        cfg.setdefault("routes", "fallback"); return SearchService(StationDB(), [self.prov(verified_ops=ops)], Config(mode, **cfg), lambda: CLOCK)  # fixed clock: mock timestamps come from the docs example (14 Nov 2026)
    def test_direct_search_end_to_end(self):
        MH.trains = [("12656", {}), ("20001", {})]
        with self.svc() as s:
            r = s.search(self.P); d = r["dates"][0]
            self.assertEqual((r["mode"], r["data_source"], r["provider_calls"], r["complete"]), ("production", "railcore", 3, True))
            self.assertEqual([x["train"] for x in d["direct"]], ["12656"]); x = d["direct"][0]
            self.assertEqual((x["status"], x["fare"], x["source"], x["freshness_mode"], x["cached"]), ("AVAILABLE-4", 965, "railcore", "live", False))
            self.assertEqual(x["provider_updated_at"], "2026-11-14T08:15:46.547000+05:30"); self.assertIsNotNone(x["retrieved_at"]); self.assertIsNotNone(x["provider_age_seconds"])
            r2 = s.search(self.P); self.assertEqual(r2["provider_calls"], 1); y = r2["dates"][0]["direct"][0]  # availability served from cache and labelled
            self.assertTrue(y["cached"]); self.assertEqual(y["checked_at"], x["checked_at"])
        self.assertNotIn(KEY, json.dumps([r, r2]))
    def test_stale_source_hidden_with_notice(self):
        MH.trains = [("20012", {})]
        with self.svc() as s: d = s.search(self.P)["dates"][0]
        self.assertEqual(d["direct"], []); self.assertIn("Some availability was older than the freshness limit and was hidden.", d["notices"])
    def test_not_live_hidden_with_notice(self):
        MH.trains = [("20011", {})]
        with self.svc() as s: d = s.search(self.P)["dates"][0]
        self.assertEqual(d["direct"], []); self.assertIn("Some data was not live and was hidden.", d["notices"])
    def test_class_prefilter_saves_calls(self):
        MH.trains = [("30010", {"classes": ["SL"]})]
        with self.svc() as s: r = s.search(self.P)
        self.assertEqual((len([l for l in MH.log if l[0].endswith("availability/seats")]), r["dates"][0]["direct"], r["complete"]), (0, [], True)); self.assertIn("Some trains do not offer this class.", r["dates"][0]["notices"])
    def test_not_offered_is_notice_not_error(self):
        MH.trains = [("20016", {})]
        with self.svc() as s: r = s.search(self.P)
        self.assertEqual((r["complete"], r["dates"][0]["errors"]), (True, []))
    def test_call_budget(self):
        MH.trains = [("12656", {}), ("20001", {})]
        with self.svc(max_calls=2) as s: r = s.search(self.P)
        self.assertEqual(r["provider_calls"], 2); self.assertFalse(r["complete"]); self.assertIn("request budget reached", r["dates"][0]["errors"])
    def test_quota_exhausted_is_error_not_unavailable(self):
        MH.trains = [("20019", {})]
        with self.svc() as s: r = s.search(self.P)
        self.assertFalse(r["complete"]); self.assertEqual(r["dates"][0]["direct"], []); self.assertTrue(r["dates"][0]["errors"]); self.assertNotIn(KEY, json.dumps(r))
    def test_auth_failure_safe_message(self):
        with self.svc() as s: r = s.search(dict(self.P, date="2026-12-31"))
        self.assertEqual(r["dates"][0]["error"], "Provider rejected the credentials."); self.assertNotIn(KEY, json.dumps(r))
    def test_routes_always_vs_fallback(self):
        MH.trains = [("12656", {})]
        with self.svc(routes="fallback") as s: a = s.search(self.P)["provider_calls"]
        MH.hits.clear()
        with self.svc(routes="always") as s: b = s.search(self.P)["provider_calls"]
        self.assertGreater(b, a)
    def test_production_needs_both_verified_ops(self):
        for ops in ("", "get_availability", "trains_between"):
            MH.log.clear()
            with self.svc(ops=ops) as s:
                with self.assertRaises(ServiceError) as c: s.search(self.P)
            self.assertEqual((c.exception.code, MH.log), ("NO_VERIFIED_PROVIDER", []))
    def test_demo_mode_never_uses_real_provider(self):
        with SearchService(StationDB(), [self.prov(), DemoProvider()], Config("demo")) as s: r = s.search(self.P)
        self.assertEqual(r["data_source"], "DEMO"); self.assertEqual(MH.log, [])
    def test_api_response_has_no_key(self):
        MH.trains = [("12656", {})]; app = make_app(Config("production", routes="fallback"), providers=[self.prov()], access_code="correct-horse-1"); st = {}
        raw = json.dumps(self.P).encode(); env = {"PATH_INFO": "/api/search", "REQUEST_METHOD": "POST", "QUERY_STRING": "", "REMOTE_ADDR": "1.2.3.4", "CONTENT_TYPE": "application/json", "CONTENT_LENGTH": str(len(raw)), "wsgi.input": io.BytesIO(raw), "HTTP_X_ACCESS_CODE": "correct-horse-1"}
        out = b"".join(app(env, lambda s, h: st.update(s=int(s[:3])))).decode(); app.close()
        self.assertEqual(st["s"], 200); self.assertNotIn(KEY, out); self.assertIn('"data_source": "railcore"', out)
class Status(unittest.TestCase):
    def test_normalize_pure(self):
        self.assertEqual(normalize_status({"status": "REGRET", "available_count": 9, "availability_text": "AVAILABLE-9"}), "REGRET")
        self.assertEqual(normalize_status({}), "UNKNOWN"); self.assertEqual(normalize_status({"status": "WAITLIST"}), "UNKNOWN"); self.assertEqual(normalize_status({"status": "RAC"}), "RAC")
        self.assertEqual(normalize_status({"status": "AVAILABLE", "available_count": True}), "AVAILABLE")
class Config2(unittest.TestCase):
    def test_new_config_bounds(self):
        for kw in (dict(max_age=10), dict(max_calls=0), dict(routes="x")):
            with self.assertRaises(ValueError): Config(**kw)
        os.environ.update(PROVIDER_MAX_AGE_SECONDS="600", PROVIDER_MAX_CALLS_PER_SEARCH="12", ROUTES_MODE="fallback")
        try: c = Config.from_env(); self.assertEqual((c.max_age, c.max_calls, c.routes), (600, 12, "fallback"))
        finally: [os.environ.pop(k) for k in ("PROVIDER_MAX_AGE_SECONDS", "PROVIDER_MAX_CALLS_PER_SEARCH", "ROUTES_MODE")]
if __name__ == "__main__": unittest.main()
