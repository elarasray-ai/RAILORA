"""WSGI API (stdlib, threaded). Run: python3 backend/api.py  |  FastAPI wrapper: fastapi_app.py (UNVERIFIED)."""
import hmac, json, os, threading, time
from datetime import datetime, timedelta, timezone
from socketserver import ThreadingMixIn
from urllib.parse import parse_qs
from wsgiref.simple_server import make_server, WSGIServer
from service import Config, StationDB, SearchService, ServiceError, clean_code
from providers.demo import DemoProvider
from providers.railcore import RailCoreProvider
from tools.verify_provider import run_checks
MAX_QUERY, MAX_Q, VERIFY_KEYS = 512, 64, {"frm", "to", "date", "cls", "quota"}
IST = timezone(timedelta(hours=5, minutes=30))
VERIFY_PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8"><title>RAILORA live check</title><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light dark">
<style>body{font:16px system-ui,sans-serif;margin:16px;max-width:640px}input,button{font:inherit;min-height:48px;width:100%;margin:4px 0 12px;padding:0 12px;box-sizing:border-box}pre{white-space:pre-wrap;word-break:break-word;border:1px solid #8886;border-radius:12px;padding:12px}</style></head><body>
<h2>RailCore live check</h2><p>Runs one trains-between and one availability call (2 RailCore requests). Leave route fields empty to use BSL to ADI, 3A, GN, 7 days ahead.</p>
<label>Access code<input id="code" type="password" autocomplete="off"></label>
<label>From (optional)<input id="frm" autocapitalize="characters"></label><label>To (optional)<input id="to" autocapitalize="characters"></label>
<label>Date YYYY-MM-DD (optional)<input id="date"></label><label>Class (optional)<input id="cls" autocapitalize="characters"></label>
<button id="go">Run live check</button><pre id="o">Not run yet.</pre>
<script>const g=i=>document.getElementById(i),o=g("o");g("go").onclick=async()=>{o.textContent="Running...";const b={};for(const k of ["frm","to","date","cls"]){const v=g(k).value.trim();if(v)b[k]=v}
try{const r=await fetch("/api/admin/verify",{method:"POST",headers:{"Content-Type":"application/json","X-Access-Code":g("code").value},body:JSON.stringify(b)});o.textContent=r.status+"\\n"+JSON.stringify(await r.json(),null,2)}catch(e){o.textContent="Could not reach the server."}};</script></body></html>"""
class RateLimiter:
    """Per-key sliding window. Expired keys are swept; tracked keys are capped (oldest evicted)."""
    def __init__(self, limit=60, window=60, clock=time.time, max_keys=10000):
        self.limit, self.window, self.clock, self.max_keys, self.h, self.n, self.lock = limit, window, clock, max_keys, {}, 0, threading.Lock()
    def sweep(self, now):
        self.h = {k: v for k, v in self.h.items() if v and now - v[-1] < self.window}
        while len(self.h) > self.max_keys: self.h.pop(next(iter(self.h)))
    def allow(self, k):
        with self.lock:
            now = self.clock(); self.n += 1
            if self.n % 100 == 0 or len(self.h) > self.max_keys: self.sweep(now)
            h = [t for t in self.h.get(k, []) if now - t < self.window]
            if len(h) >= self.limit: self.h[k] = h; return False
            self.h[k] = h + [now]; return True
    def size(self): return len(self.h)
def make_app(cfg=None, providers=None, limiter=None, db=None, max_body=None, access_code=None, verify_factory=None, clock=time.time):
    cfg = cfg or Config.from_env(); own = db is None; db = db or StationDB(os.environ.get("RAILORA_DB_PATH", ":memory:"))
    svc = SearchService(db, providers if providers is not None else [RailCoreProvider(), DemoProvider()], cfg); limiter = limiter or RateLimiter()
    max_body = max_body or int(os.environ.get("RAILORA_MAX_BODY", 16384)); origin = os.environ.get("ALLOWED_ORIGIN", "")
    access = os.environ.get("RAILORA_ACCESS_CODE", "") if access_code is None else access_code
    if access and len(access) < 8: raise ValueError("RAILORA_ACCESS_CODE must be at least 8 characters")
    bad, verify_factory, last_verify = RateLimiter(limit=10, window=300, clock=clock), verify_factory or (lambda: RailCoreProvider()), [0.0]
    def gate(env):  # production spends real provider quota: require the access code. Wrong attempts are limited (shared bucket).
        if cfg.mode != "production": return
        if not access: raise ServiceError("ACCESS_CODE_NOT_SET", "This server has no access code configured.", 503)
        if hmac.compare_digest(env.get("HTTP_X_ACCESS_CODE", "").encode(), access.encode()): return
        if not bad.allow("wrong"): raise ServiceError("RATE_LIMITED", "Too many wrong attempts. Try again later.", 429)
        raise ServiceError("ACCESS_REQUIRED", "Access code required.", 401)
    def read_json(env):
        if env.get("CONTENT_TYPE", "").split(";")[0].strip().lower() != "application/json":
            raise ServiceError("UNSUPPORTED_MEDIA_TYPE", "Send JSON with Content-Type: application/json.", 415)
        try: n = int(env.get("CONTENT_LENGTH") or 0)
        except ValueError: raise ServiceError("INVALID_INPUT", "Invalid Content-Length.")
        if n < 0: raise ServiceError("INVALID_INPUT", "Invalid Content-Length.")
        if n > max_body: raise ServiceError("PAYLOAD_TOO_LARGE", "Request body too large.", 413)
        try: return json.loads(env["wsgi.input"].read(n) or b"{}")
        except (ValueError, RecursionError): raise ServiceError("INVALID_INPUT", "Request body must be valid JSON.")
    def app(env, start):
        def out(code, obj):
            h = [("Content-Type", "application/json"), ("Cache-Control", "no-store")] + ([("Access-Control-Allow-Origin", origin)] if origin else [])
            start(f"{code} X", h); return [json.dumps(obj, default=str).encode()]
        def html(s): start("200 OK", [("Content-Type", "text/html; charset=utf-8"), ("Cache-Control", "no-store")]); return [s.encode()]
        try:
            if not limiter.allow(env.get("REMOTE_ADDR", "?")): raise ServiceError("RATE_LIMITED", "Too many requests. Try again shortly.", 429)
            path, m, raw_qs = env["PATH_INFO"], env["REQUEST_METHOD"], env.get("QUERY_STRING", "")
            if len(raw_qs) > MAX_QUERY: raise ServiceError("INVALID_INPUT", "Query string too long.", 414)
            qs = parse_qs(raw_qs)
            if path == "/" and m == "GET":
                f = os.path.join(os.path.dirname(__file__), "..", "public", "index.html")
                if not os.path.exists(f): raise ServiceError("NOT_FOUND", "Frontend not found.", 404)
                with open(f, encoding="utf-8") as fh: page = fh.read()
                return html(page.replace("<head>", f'<head><script>window.RAILORA_API=location.origin;window.RAILORA_MODE="{cfg.mode}"</script>', 1))
            if path == "/verify" and m == "GET" and cfg.mode == "production": return html(VERIFY_PAGE)
            if path == "/health": return out(200, {"status": "ok", "mode": cfg.mode})
            if path == "/api/stations" and m == "GET":
                q = qs.get("q", [""])[0]
                if len(q) > MAX_Q: raise ServiceError("INVALID_INPUT", "Search text too long.")
                return out(200, {"stations": db.search(q)})
            if path == "/api/nearby" and m == "GET": return out(200, {"nearby": db.nearby(clean_code(qs.get("code", [""])[0]))})
            if path == "/api/search" and m == "POST": gate(env); return out(200, svc.search(read_json(env)))
            if path == "/api/admin/verify" and m == "POST" and cfg.mode == "production":
                gate(env); body = read_json(env)
                if not isinstance(body, dict) or set(body) - VERIFY_KEYS or not all(isinstance(v, str) and len(v) <= 12 for v in body.values()): raise ServiceError("INVALID_INPUT", "Invalid verification request.")
                if clock() - last_verify[0] < 30: raise ServiceError("RATE_LIMITED", "Wait 30 seconds between live checks.", 429)
                last_verify[0] = clock(); d = {"frm": "BSL", "to": "ADI", "date": (datetime.now(IST).date() + timedelta(days=7)).isoformat(), "cls": "3A", "quota": "GN", **body}
                rep = run_checks(verify_factory(), d["frm"], d["to"], d["date"], d["cls"], d["quota"])  # evidence only: never enables a capability
                rep["capabilities_enabled"] = sorted(o.strip() for o in os.environ.get("RAILCORE_VERIFIED_OPS", "").split(",") if o.strip())
                return out(200, rep)
            return out(404, {"error": {"code": "NOT_FOUND", "message": "Unknown route."}})
        except ServiceError as e: return out(e.status, {"error": {"code": e.code, "message": str(e)}})
        except Exception: return out(500, {"error": {"code": "INTERNAL", "message": "Something went wrong."}})  # sanitized
    app.close = (lambda: svc.close()) if own else (lambda: None)
    return app
def bind_address(env=os.environ):
    """Render needs 0.0.0.0 on $PORT (default 10000). Locally we stay on loopback unless HOST says otherwise."""
    return env.get("HOST") or ("0.0.0.0" if env.get("RENDER") == "true" else "127.0.0.1"), int(env.get("PORT", 10000))
class ThreadedServer(ThreadingMixIn, WSGIServer): daemon_threads = True
def make_threaded_server(host, port, app): return make_server(host, port, app, server_class=ThreadedServer)
if __name__ == "__main__":
    host, port = bind_address(); app = make_app(); print(f"RAILORA API on {host}:{port} mode=" + Config.from_env().mode, flush=True)
    srv = make_threaded_server(host, port, app)
    try: srv.serve_forever()
    finally: srv.server_close(); app.close()
