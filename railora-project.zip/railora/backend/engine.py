"""RAILORA core rules. Pure stdlib. No network. Contains no railway data besides a station reference list."""
import re
from datetime import timedelta

STATIONS = [  # (code, name, city, state) - verify against official dataset before production
 ("LTT","Lokmanya Tilak Terminus","Mumbai","Maharashtra"),
 ("CSMT","Chhatrapati Shivaji Maharaj Terminus","Mumbai","Maharashtra"),
 ("DR","Dadar","Mumbai","Maharashtra"),
 ("BDTS","Bandra Terminus","Mumbai","Maharashtra"),
 ("MMCT","Mumbai Central","Mumbai","Maharashtra"),
 ("KYN","Kalyan Junction","Kalyan","Maharashtra"),
 ("TNA","Thane","Thane","Maharashtra"),
 ("JNU","Jaunpur Junction","Jaunpur","Uttar Pradesh"),
 ("ZNP","Jaunpur City","Jaunpur","Uttar Pradesh"),
 ("BSB","Varanasi Junction","Varanasi","Uttar Pradesh"),
 ("PRYJ","Prayagraj Junction","Prayagraj","Uttar Pradesh"),
 ("BSL","Bhusaval Junction","Bhusaval","Maharashtra"),("ADI","Ahmedabad Junction","Ahmedabad","Gujarat"),("NDLS","New Delhi","New Delhi","Delhi"),
 ("HWH","Howrah Junction","Kolkata","West Bengal"),("MAS","Chennai Central","Chennai","Tamil Nadu"),("SBC","KSR Bengaluru City Junction","Bengaluru","Karnataka"),
 ("PUNE","Pune Junction","Pune","Maharashtra"),("ST","Surat","Surat","Gujarat"),("BRC","Vadodara Junction","Vadodara","Gujarat"),("NGP","Nagpur Junction","Nagpur","Maharashtra"),
 ("BPL","Bhopal Junction","Bhopal","Madhya Pradesh"),("LKO","Lucknow Charbagh NR","Lucknow","Uttar Pradesh"),("CNB","Kanpur Central","Kanpur","Uttar Pradesh"),
 ("PNBE","Patna Junction","Patna","Bihar"),("JP","Jaipur Junction","Jaipur","Rajasthan"),("SC","Secunderabad Junction","Hyderabad","Telangana"),
]
ALIASES = {"LTT":["kurla terminus"],"CSMT":["bombay vt","victoria terminus","cst"],"BSB":["banaras","benares","kashi"],"PRYJ":["allahabad"],"NDLS":["delhi"],"HWH":["calcutta"],"MAS":["madras"],"SBC":["bangalore"],"PUNE":["poona"],"BRC":["baroda"]}
for c in ("LTT","CSMT","DR","BDTS","MMCT"): ALIASES.setdefault(c,[]).append("bombay")

def norm(s): return re.sub(r"[^a-z0-9 ]", "", s.lower()).strip()

def search_stations(q):
    """Returns ALL matches. Caller must make the user pick; never auto-select."""
    n = norm(q)
    if not n: return []
    out = []
    for code, name, city, state in STATIONS:
        keys = [norm(name), norm(city), code.lower()] + [norm(a) for a in ALIASES.get(code, [])]
        if any(k.startswith(n) or (len(n) >= 3 and n in k) for k in keys):
            out.append({"code": code, "name": name, "city": city, "state": state})
    return out

def parse_status(raw):
    if not raw: return ("UNKNOWN", None)
    s = raw.strip().upper()
    m = re.fullmatch(r"(?:AVAILABLE|AVL)[\s-]*0*(\d+)", s)
    if m: return ("AVAILABLE", int(m[1]))
    if s in ("AVAILABLE", "AVL"): return ("AVAILABLE", None)
    m = re.fullmatch(r"(?:[A-Z]{1,3})?WL[\s/-]*0*(\d+)", s)
    if m: return ("WL", int(m[1]))
    if s.startswith("RAC"): return ("RAC", None)
    if "REGRET" in s: return ("REGRET", None)
    if s in ("TRAIN_CANCELLED", "TRAIN CANCELLED"): return ("CANCELLED", None)
    if s in ("TRAIN_DEPARTED", "TRAIN DEPARTED"): return ("DEPARTED", None)
    if s in ("NOT AVAILABLE", "NOT AVL", "NA"): return ("NOT_AVAILABLE", None)
    return ("UNKNOWN", None)

def is_displayable(rec, pax=1, include_wl=False, now=None, ttl_s=300):
    """rec: {status, verified, checked_at}. Returns (ok, reason). Stale/unverified data is never shown as live."""
    if rec.get("error"): return False, "provider_error"
    if not rec.get("verified"): return False, "unverified"
    if now is not None and (now - rec["checked_at"]).total_seconds() > ttl_s: return False, "stale"
    kind, n = parse_status(rec.get("status"))
    if kind == "AVAILABLE":
        if n is None: return (pax == 1), ("ok" if pax == 1 else "count_unknown")
        return (n >= pax), ("ok" if n >= pax else "not_enough_seats")
    if kind == "WL": return (include_wl and 1 <= n <= 5), ("ok" if include_wl and n <= 5 else "wl_hidden")
    return False, kind.lower()

def safe_availability(fetch, **kw):
    """A failed request is an ERROR, never 'not available'."""
    try: return {"status": fetch(**kw), "verified": True, "error": None}
    except Exception as e: return {"status": None, "verified": False, "error": type(e).__name__}

class TTLCache:
    def __init__(self, ttl_s, clock): self.ttl, self.clock, self.d = ttl_s, clock, {}
    def set(self, k, v): self.d[k] = (self.clock(), v)
    def get(self, k):
        t = self.d.get(k)
        return t[1] if t and (self.clock() - t[0]).total_seconds() <= self.ttl else None

def total_fare(*fares): return None if any(f is None for f in fares) else sum(fares)

def find_connections(legs, origin, dests, budget, min_buffer=60, max_wait=240, transfer=None, limit=2):
    """Exactly two legs / two tickets. legs: {train,frm,to,dep,arr (datetime),fare,ok}. transfer: {(to,frm):extra_min}."""
    transfer = transfer or {}
    res = []
    for a in legs:
        if a["frm"] != origin or not a["ok"]: continue
        for b in legs:
            if not b["ok"] or b["to"] not in dests or b["train"] == a["train"]: continue
            if a["to"] != b["frm"] and (a["to"], b["frm"]) not in transfer: continue
            extra = 0 if a["to"] == b["frm"] else transfer[(a["to"], b["frm"])]
            wait = (b["dep"] - a["arr"]) / timedelta(minutes=1)
            if wait < min_buffer + extra or wait > max_wait: continue
            fare = total_fare(a["fare"], b["fare"])
            if fare is None or fare > budget: continue
            res.append({"legs": (a, b), "wait_min": wait, "fare": fare, "duration_min": (b["arr"] - a["dep"]) / timedelta(minutes=1)})
    res.sort(key=lambda r: (r["fare"], r["duration_min"], r["wait_min"]))
    return res[:limit]

def nearby(candidates, max_km=120):
    """candidates: [{code,km,trains}] ranked by connectivity vs extra distance."""
    sc = [dict(c, score=round(c["trains"] / (1 + c["km"] / 20), 2)) for c in candidates if c["km"] <= max_km]
    return sorted(sc, key=lambda c: -c["score"])
