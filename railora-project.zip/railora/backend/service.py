"""Search service: station DB (sqlite), provider selection, caching, date-wise search, nearby stations, 2-ticket routes."""
import math, os, re, sqlite3, threading
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from providers.interface import ProviderError, NotOffered
from engine import STATIONS, ALIASES, norm, is_displayable, find_connections
COORDS = {"LTT":(19.069,72.896),"CSMT":(18.940,72.835),"DR":(19.018,72.844),"BDTS":(19.062,72.840),"MMCT":(18.969,72.819),
 "KYN":(19.235,73.130),"TNA":(19.186,72.976),"JNU":(25.746,82.683),"ZNP":(25.752,82.690),"BSB":(25.328,83.010),"PRYJ":(25.446,81.826)}  # approximate, verify
CLASSES = {"SL","3A","2A","1A","3E","CC","2S","EC"}
CODE, DATE = re.compile(r"[A-Z0-9]{1,5}"), re.compile(r"\d{4}-\d{2}-\d{2}")
KEYS = {"from", "to", "date", "dates", "pax", "cls", "quota", "budget", "wl", "nearby", "nearby_codes"}
def clean_code(v):
    v = v.strip().upper() if isinstance(v, str) else None
    if not v or not CODE.fullmatch(v): raise ServiceError("INVALID_INPUT", "Station codes must be 1-5 letters or digits.")
    return v
NOTICES = {"booking_not_open": "Booking has not opened for this date.", "tatkal_not_open": "Tatkal booking has not opened yet.", "class_not_offered": "Some trains do not offer this class.",
           "quota_not_offered": "Some trains do not offer this quota.", "train_not_running": "Some trains do not run on this date.", "not_offered": "Some options are not offered.",
           "stale_source": "Some availability was older than the freshness limit and was hidden.", "not_live": "Some data was not live and was hidden."}
class CallBudget:
    """Caps provider calls per search (protects paid/limited API allowances)."""
    def __init__(self, n): self.left, self.used, self.exhausted, self.lock = n, 0, False, threading.Lock()
    def take(self):
        with self.lock:
            if self.left <= 0: self.exhausted = True; return False
            self.left -= 1; self.used += 1; return True
class ServiceError(Exception):
    def __init__(self, code, msg, status=400): super().__init__(msg); self.code, self.status = code, status
class Config:
    def __init__(self, mode="demo", ttl=60, workers=4, max_dates=7, max_age=3600, max_calls=100, routes="always"):
        if mode not in ("demo", "production"): raise ValueError("RAILORA_MODE must be demo or production")
        if not (1 <= ttl <= 300): raise ValueError("AVAILABILITY_TTL_SECONDS must be between 1 and 300")
        if not (60 <= max_age <= 86400): raise ValueError("PROVIDER_MAX_AGE_SECONDS must be between 60 and 86400")
        if not (1 <= max_calls <= 1000): raise ValueError("PROVIDER_MAX_CALLS_PER_SEARCH must be between 1 and 1000")
        if routes not in ("always", "fallback", "off"): raise ValueError("ROUTES_MODE must be always, fallback or off")
        self.max_age, self.max_calls, self.routes = max_age, max_calls, routes
        self.mode, self.ttl, self.workers, self.max_dates = mode, ttl, workers, max_dates
    @classmethod
    def from_env(cls):
        e = os.environ.get
        return cls(e("RAILORA_MODE", "demo"), int(e("AVAILABILITY_TTL_SECONDS", 60)), max_age=int(e("PROVIDER_MAX_AGE_SECONDS", 3600)),
                   max_calls=int(e("PROVIDER_MAX_CALLS_PER_SEARCH", 100)), routes=e("ROUTES_MODE", "always"))
def km(a, b):
    la1, lo1, la2, lo2 = map(math.radians, (*a, *b)); h = math.sin((la2-la1)/2)**2 + math.cos(la1)*math.cos(la2)*math.sin((lo2-lo1)/2)**2
    return 6371 * 2 * math.asin(math.sqrt(h))
def _locked(f):
    def w(self, *a, **k):
        with self.lock: return f(self, *a, **k)
    w.__name__ = f.__name__; return w
class StationDB:
    def __init__(self, path=":memory:"):
        self.lock = threading.RLock(); self.c = sqlite3.connect(path, check_same_thread=False)
        with open(os.path.join(os.path.dirname(__file__), "migrations", "001_stations.sql"), encoding="utf-8") as f: self.c.executescript(f.read())
        if not self.c.execute("SELECT 1 FROM stations").fetchone(): self.seed()
    def close(self):
        c, self.c = getattr(self, "c", None), None
        if c is not None: c.close()
    def __enter__(self): return self
    def __exit__(self, *a): self.close()
    def __del__(self):  # safety net only; callers should close() or use `with`
        try: self.close()
        except Exception: pass
    def seed(self):
        for code, name, city, state in STATIONS:
            la, lo = COORDS.get(code, (None, None)); self.c.execute("INSERT INTO stations VALUES(?,?,?,?,?,?)", (code, name, city, state, la, lo))
            for a in ALIASES.get(code, []): self.c.execute("INSERT INTO aliases VALUES(?,?)", (norm(a), code))
        self.c.commit()
    @_locked
    def get(self, code):
        r = self.c.execute("SELECT code,name,city,state,lat,lon FROM stations WHERE code=?", (code,)).fetchone()
        return dict(zip(("code","name","city","state","lat","lon"), r)) if r else None
    @_locked
    def all_codes(self): return [r[0] for r in self.c.execute("SELECT code FROM stations")]
    @_locked
    def search(self, q, limit=10):
        n = norm(q)
        if len(n) < 2: return []
        p = f"%{n}%" if len(n) >= 3 else f"{n}%"
        rows = self.c.execute("""SELECT code,name,city,state FROM stations WHERE lower(name) LIKE ? OR lower(city) LIKE ? OR lower(code) LIKE ?
          OR code IN (SELECT code FROM aliases WHERE alias LIKE ?) ORDER BY name LIMIT ?""", (p, p, p, p, limit)).fetchall()
        return [dict(zip(("code","name","city","state"), r)) for r in rows]
    @_locked
    def nearby(self, code, max_km=60, limit=3):
        s = self.get(code)
        if not s or s["lat"] is None: return []
        out = []
        for c in self.all_codes():
            o = self.get(c)
            if c != code and o["lat"] is not None:
                d = km((s["lat"], s["lon"]), (o["lat"], o["lon"]))
                if d <= max_km: out.append({"code": c, "name": o["name"], "extra_km": round(d, 1), "relevance": "distance_only"})
        return sorted(out, key=lambda x: x["extra_km"])[:limit]
class SearchService:
    def __init__(self, db, providers, cfg, clock=lambda: datetime.now(timezone.utc)):
        self.db, self.providers, self.cfg, self.clock, self.cache = db, providers, cfg, clock, {}
    def provider(self):
        for p in self.providers:
            if getattr(p, "synthetic", False) != (self.cfg.mode == "demo"): continue  # demo mode: synthetic only; production: real only
            if p.capabilities.get("get_availability") and p.capabilities.get("trains_between"): return p
        raise ServiceError("NO_VERIFIED_PROVIDER", "No verified railway data provider is configured.", 503)
    def close(self): self.db.close()
    def __enter__(self): return self
    def __exit__(self, *a): self.close()
    def validate(self, p):
        bad = lambda f: ServiceError("INVALID_INPUT", f"Invalid {f}.")
        if not isinstance(p, dict) or set(p) - KEYS: raise bad("request")
        if "from" not in p or "to" not in p: raise bad("stations")
        frm, to = clean_code(p["from"]), clean_code(p["to"])
        raw = p["dates"] if p.get("dates") is not None else ([p["date"]] if "date" in p else None)
        if not isinstance(raw, list) or not raw or not all(isinstance(d, str) and DATE.match(d) for d in raw): raise bad("dates")
        try:
            for d in raw: datetime.fromisoformat(d)
        except ValueError: raise bad("dates")
        dates = list(dict.fromkeys(raw))
        if len(dates) > self.cfg.max_dates: raise bad("dates (too many)")
        pax = p.get("pax", 1); cls = p.get("cls", "3A"); quota = p.get("quota", "GN"); b = p.get("budget", 1e9)
        if type(pax) is not int or not 1 <= pax <= 6: raise bad("passenger count")
        if cls not in CLASSES: raise bad("class")
        if not isinstance(quota, str) or not re.fullmatch(r"[A-Z]{2,3}", quota): raise bad("quota")
        if isinstance(b, bool) or not isinstance(b, (int, float)) or not math.isfinite(b) or not 0 <= b <= 1e9: raise bad("budget")
        for k in ("wl", "nearby"):
            if not isinstance(p.get(k, False), bool): raise bad(k)
        nc = p.get("nearby_codes")
        if nc is not None and (not isinstance(nc, list) or len(nc) > 10): raise bad("nearby stations")
        r = dict(frm=frm, to=to, dates=dates, pax=pax, cls=cls, quota=quota, budget=float(b), wl=p.get("wl", False), nearby=p.get("nearby", False),
                 nearby_codes=None if nc is None else [clean_code(c) for c in nc], calls=CallBudget(self.cfg.max_calls))
        for k in ("frm", "to"):
            if not self.db.get(r[k]): raise ServiceError("UNKNOWN_STATION", f"Unknown station code {r[k]}.")
        if r["frm"] == r["to"]: raise ServiceError("INVALID_INPUT", "From and To must differ.")
        return r
    def _avail(self, prov, leg, date, p):
        key = (prov.name, leg["train"], leg["frm"], leg["to"], date, p["cls"], p["quota"]); now = self.clock(); hit = self.cache.get(key)
        if hit and (now - hit["checked_at"]).total_seconds() <= self.cfg.ttl: return dict(hit, cached=True)  # original checked_at kept
        base = {"fare": None, "checked_at": now, "cached": False}
        if not p["calls"].take(): return dict(base, status=None, verified=False, error="CallBudgetExhausted")
        try:
            r = prov.get_availability(leg["train"], leg["frm"], leg["to"], date, p["cls"], p["quota"])
            rec = dict(base, status=r["status"], fare=r.get("fare"), verified=bool(r.get("live", True)), error=None,
                       **{k: r.get(k) for k in ("provider_updated_at", "retrieved_at", "freshness_mode")}); self.cache[key] = rec; return rec
        except NotOffered as e:
            rec = dict(base, status="NOT_OFFERED", verified=True, error=None, notice=e.reason); self.cache[key] = rec; return rec
        except Exception as e:  # failure is an ERROR, never "not available"; not cached
            return dict(base, status=None, verified=False, error=type(e).__name__)
    def _tb(self, prov, ab, date, p):
        if not p["calls"].take(): return []
        try: return prov.trains_between(*ab, date)
        except NotOffered: return []
    def _rec(self, prov, l, date, p):
        if "classes" in l and p["cls"] not in l["classes"]:  # saves a provider call
            return {"status": "NOT_OFFERED", "fare": None, "verified": True, "checked_at": self.clock(), "error": None, "cached": False, "notice": "class_not_offered"}
        return self._avail(prov, l, date, p)
    def _legs(self, prov, pairs, date, p):
        with ThreadPoolExecutor(self.cfg.workers) as ex: lists = list(ex.map(lambda ab: self._tb(prov, ab, date, p), pairs))
        legs = [l for ls in lists for l in ls]
        with ThreadPoolExecutor(self.cfg.workers) as ex: recs = list(ex.map(lambda l: self._rec(prov, l, date, p), legs))
        now = self.clock(); out, errs, notes = [], [], set()
        for l, r in zip(legs, recs):
            ok, why = is_displayable(r, p["pax"], p["wl"], now, self.cfg.ttl); ps = r.get("provider_updated_at")
            if ok and ps is not None and (now - ps).total_seconds() > self.cfg.max_age: ok = False; notes.add("stale_source")
            if why == "unverified" and r.get("freshness_mode") not in (None, "live"): notes.add("not_live")
            if why == "provider_error" and r["error"] != "CallBudgetExhausted": errs.append(f"{l['train']} {l['frm']}-{l['to']}: provider_error")
            if r.get("notice"): notes.add(r["notice"])
            out.append(dict(l, ok=ok, rec=r, fare=None if r["fare"] is None else r["fare"] * p["pax"]))
        return out, errs, notes
    def _nb(self, c, p):
        n = self.db.nearby(c) if p["nearby"] else []
        return [x for x in n if p["nearby_codes"] is None or x["code"] in p["nearby_codes"]]
    def _one(self, prov, p, date):
        now = self.clock(); near = lambda c: [{"code": c, "extra_km": 0}] + self._nb(c, p)
        O, D = near(p["frm"]), near(p["to"]); dc = {d["code"] for d in D}
        direct, errs, notes = self._legs(prov, [(o["code"], d["code"]) for o in O for d in D], date, p)
        shown = [l for l in direct if l["ok"] and (l["fare"] is None or l["fare"] <= p["budget"])]
        mids = [c for c in self.db.all_codes() if c not in dc and c not in {o["code"] for o in O}]
        if self.cfg.routes == "off" or (self.cfg.routes == "fallback" and shown): legs, e2, n2 = [], [], set()
        else: legs, e2, n2 = self._legs(prov, [(o["code"], m) for o in O for m in mids] + [(m, d) for m in mids for d in dc], date, p)
        if p["calls"].exhausted: errs.append("request budget reached")
        routes = []
        for o in O: routes += find_connections(legs, o["code"], dc, p["budget"])
        routes = sorted(routes, key=lambda r: (r["fare"], r["duration_min"], r["wait_min"]))[:2]
        iso = lambda t: None if t is None else t.isoformat(); age = lambda t: None if t is None else int((now - t).total_seconds())
        fmt = lambda l: {"train": l["train"], "name": l["name"], "from": l["frm"], "to": l["to"], "dep": l["dep"].isoformat(), "arr": l["arr"].isoformat(),
                         "status": l["rec"]["status"], "fare": l["fare"], "checked_at": l["rec"]["checked_at"].isoformat(), "cached": l["rec"].get("cached", False),
                         "age_seconds": int((now - l["rec"]["checked_at"]).total_seconds()), "source": prov.name,
                         "provider_updated_at": iso(l["rec"].get("provider_updated_at")), "provider_age_seconds": age(l["rec"].get("provider_updated_at")),
                         "retrieved_at": iso(l["rec"].get("retrieved_at")), "freshness_mode": l["rec"].get("freshness_mode")}
        return {"date": date, "direct": [fmt(l) for l in shown],
                "routes": [{"legs": [fmt(x) for x in r["legs"]], "wait_min": r["wait_min"], "fare": r["fare"], "duration_min": r["duration_min"],
                            "separate_tickets": True} for r in routes], "errors": sorted(set(errs + e2)), "notices": [NOTICES.get(n, NOTICES["not_offered"]) for n in sorted(notes | n2)], "error": None}
    def search(self, raw):
        p = self.validate(raw); prov = self.provider()
        def day(d):
            try: return self._one(prov, p, d)
            except Exception as e: return {"date": d, "direct": [], "routes": [], "errors": [], "error": str(e) if isinstance(e, ProviderError) else "provider_error"}
        with ThreadPoolExecutor(self.cfg.workers) as ex: days = list(ex.map(day, p["dates"]))
        return {"mode": self.cfg.mode, "data_source": "DEMO" if getattr(prov, "synthetic", False) else prov.name,
                "nearby": {"from": self._nb(p["frm"], p), "to": self._nb(p["to"], p)} if p["nearby"] else None,
                "provider_calls": p["calls"].used, "call_limit": self.cfg.max_calls, "complete": all(d["error"] is None and not d["errors"] for d in days), "dates": days}
