"""Shared HTTP plumbing for real adapters: timeout, capped retry with exponential backoff, error classification, circuit breaker.
Contains NO provider endpoints. Errors never include URLs, keys or upstream text."""
import json, socket, time, urllib.error, urllib.parse, urllib.request
from .interface import Provider, ProviderAuthError, ProviderRateLimited, ProviderUnavailable, ProviderBadResponse, ProviderQuotaExhausted
MAX_RESPONSE = 2_000_000
def _retry_after(h):
    try: v = float(h); return v if 0 <= v <= 3600 else None
    except (TypeError, ValueError): return None
class CircuitBreaker:
    def __init__(self, threshold=5, cooldown=30.0, clock=time.monotonic): self.threshold, self.cooldown, self.clock, self.fails, self.open_until = threshold, cooldown, clock, 0, 0.0
    def allow(self): return self.clock() >= self.open_until
    def ok(self): self.fails = 0
    def fail(self):
        self.fails += 1
        if self.fails >= self.threshold: self.open_until, self.fails = self.clock() + self.cooldown, 0
class HttpAdapter(Provider):
    max_retry_after = 10.0  # never sleep longer than this inside a request
    def __init__(self, base_url, api_key=None, key_header="Authorization", timeout=5.0, max_retries=2, backoff=0.5, sleep=time.sleep, breaker=None):
        self.base, self.key, self.key_header, self.timeout, self.max_retries, self.backoff, self.sleep = base_url.rstrip("/"), api_key, key_header, timeout, max_retries, backoff, sleep
        self.breaker = breaker or CircuitBreaker()
    def classify_error(self, code, body, retry_after):
        """Raise a non-retryable ProviderError, or return a retryable one. Subclasses extend this (body is parsed JSON or None)."""
        if code in (401, 403): raise ProviderAuthError("Provider rejected the credentials.")
        if code == 402: raise ProviderQuotaExhausted("Provider request allowance is used up.")
        if code == 429: raise ProviderRateLimited("Provider rate limit reached.", retry_after)
        if code >= 500: return ProviderUnavailable("Provider reported an error.")
        raise ProviderBadResponse("Provider rejected the request.")
    def _get(self, path, params=None):
        if not self.breaker.allow(): raise ProviderUnavailable("Provider temporarily paused after repeated failures.")
        url = self.base + path + ("?" + urllib.parse.urlencode(params) if params else ""); headers = {"Accept": "application/json"}
        if self.key: headers[self.key_header] = self.key
        last = ProviderUnavailable("Provider did not respond.")
        for attempt in range(self.max_retries + 1):  # never retries indefinitely
            ra = None
            try:
                with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=self.timeout) as r: raw = r.read(MAX_RESPONSE + 1)
                if len(raw) > MAX_RESPONSE: raise ProviderBadResponse("Provider response too large.")
                data = json.loads(raw); self.breaker.ok(); return data
            except urllib.error.HTTPError as e:
                try: body = json.loads(e.read(65536))
                except Exception: body = None
                ra = _retry_after(e.headers.get("Retry-After") if e.headers else None); code = e.code; e.close()
                last = self.classify_error(code, body, ra)
            except (urllib.error.URLError, socket.timeout, TimeoutError, ConnectionError): last = ProviderUnavailable("Provider did not respond.")
            except ValueError: raise ProviderBadResponse("Provider returned invalid data.")
            if attempt < self.max_retries: self.sleep(max(self.backoff * 2 ** attempt, min(ra or 0, self.max_retry_after)))
        self.breaker.fail(); raise last
