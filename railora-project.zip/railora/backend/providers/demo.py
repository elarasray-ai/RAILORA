"""SYNTHETIC fixtures. Fictional trains. Only usable when RAILORA_MODE=demo."""
from datetime import datetime, timedelta
from .interface import Provider, ProviderError
F = {"2026-12-01": [
 ("90001","Demo Express A","JNU","LTT",480,1890,{"SL":("GNWL3",310),"3A":("AVAILABLE-0004",820),"2A":("REGRET",1180)}),
 ("90002","Demo Mail B","JNU","LTT",600,2160,{"SL":("GNWL8",300),"3A":("RAC 2",800),"2A":("GNWL2",1150)}),
 ("90011","Demo Link C","JNU","PRYJ",360,600,{"3A":("AVAILABLE-0009",310),"SL":("AVAILABLE-0020",130)}),
 ("90012","Demo Night D","PRYJ","LTT",720,1800,{"3A":("AVAILABLE-0003",410),"SL":("AVAILABLE-0010",180)}),
 ("90013","Demo Quick E","PRYJ","LTT",630,1740,{"3A":("AVAILABLE-0006",390)})],
 "2026-12-02": [
 ("90011","Demo Link C","JNU","PRYJ",360,600,{"3A":("AVAILABLE-0009",310)}),
 ("90012","Demo Night D","PRYJ","LTT",750,1800,{"3A":("AVAILABLE-0003",600)})]}
class DemoProvider(Provider):
    name = "demo"; synthetic = True
    capabilities = {"trains_between": True, "get_availability": True}
    def _day(self, date):
        if date not in F: raise ProviderError("no demo data for this date")
        return F[date]
    def trains_between(self, frm, to, date):
        b = datetime.fromisoformat(date)
        return [{"train": n, "name": nm, "frm": f, "to": t, "dep": b + timedelta(minutes=d), "arr": b + timedelta(minutes=a)}
                for n, nm, f, t, d, a, _ in self._day(date) if f == frm and t == to]
    def get_availability(self, train, frm, to, date, cls, quota):
        for n, _, f, t, _, _, c in self._day(date):
            if (n, f, t) == (train, frm, to):
                if cls not in c: raise ProviderError("class not offered")
                return {"status": c[cls][0], "fare": c[cls][1]}
        raise ProviderError("train not found")
