"""RailCore adapter. Written ONLY from RailCore's published docs (read 14 Nov 2026):
  https://railcore.tech/docs/api/seat-availability  GET /v1/availability/seats
  https://railcore.tech/docs/api/route-trains       GET /v1/routes/trains
  https://railcore.tech/docs/responses              envelope; branch on success, use error.code
Key: ONLY from env RAILCORE_API_KEY, sent in header X-RailCore-Key. Never logged, never in errors/responses.
Capabilities start EMPTY. Enable per op via RAILCORE_VERIFIED_OPS only after live verification (tools/verify_provider.py).
Not supported: HMAC signing (required by Growth/Scale/Enterprise keys; Free/Starter send the key alone)."""
import os, re
from datetime import datetime, timedelta, timezone
from engine import parse_status
from .http_base import HttpAdapter
from .interface import NotConfigured, NotOffered, ProviderBadResponse
BASE_URL, KEY_ENV, OPS_ENV, IMPLEMENTED = "https://ir.railcore.tech/v1", "RAILCORE_API_KEY", "RAILCORE_VERIFIED_OPS", ("trains_between", "get_availability")
IST = timezone(timedelta(hours=5, minutes=30))
R_TRAIN, R_STN, R_DATE, R_CLS, R_QUOTA, R_HM = (re.compile(x) for x in (r"[A-Z0-9]{4,6}", r"[A-Z0-9]{1,6}", r"\d{4}-\d{2}-\d{2}", r"[A-Z0-9]{1,3}", r"[A-Z]{2,3}", r"([01]\d|2[0-3]):[0-5]\d"))
REASONS = {"TATKAL_NOT_OPEN": "tatkal_not_open", "QUOTA_NOT_AVAILABLE": "quota_not_offered", "CLASS_NOT_AVAILABLE": "class_not_offered",
           "TRAIN_NOT_RUNNING": "train_not_running", "BOOKING_NOT_OPEN": "booking_not_open"}
def _ts(v):
    try: d = datetime.fromisoformat(v) if isinstance(v, str) else None
    except ValueError: return None
    return d if d is not None and d.tzinfo is not None else None
def _int(v): return v if isinstance(v, int) and not isinstance(v, bool) and v >= 0 else None
def normalize_status(c):
    """RailCore class entry -> RAILORA status string. The provider's `status` always wins: REGRET is never turned into availability."""
    st, txt = c.get("status"), c.get("availability_text"); k, tn = parse_status(txt) if isinstance(txt, str) else ("UNKNOWN", None)
    if st == "AVAILABLE":
        n = _int(c.get("available_count"))
        if n is not None and k == "AVAILABLE" and tn is not None and tn != n: return "UNKNOWN"  # count and text disagree
        if n is None and k == "AVAILABLE": n = tn
        return "AVAILABLE" if n is None else (f"AVAILABLE-{n}" if n > 0 else "UNKNOWN")
    if st == "WAITLIST":
        n = _int(c.get("waitlist_count")) or (tn if k == "WL" else None)
        return f"WL{n}" if n else "UNKNOWN"
    if st == "RAC": n = _int(c.get("rac_count")); return f"RAC {n}" if n else "RAC"
    if st == "REGRET": return "REGRET"
    if st == "NOT_AVAILABLE": return "NOT AVAILABLE"
    if st in ("TRAIN_CANCELLED", "TRAIN_DEPARTED"): return st
    return "UNKNOWN"  # unknown enum values fall through to a safe default
class RailCoreProvider(HttpAdapter):
    name, synthetic = "railcore", False
    def __init__(self, api_key=None, base_url=BASE_URL, verified_ops=None, **kw):
        super().__init__(base_url, api_key if api_key is not None else os.environ.get(KEY_ENV), "X-RailCore-Key", **kw)
        ops = os.environ.get(OPS_ENV, "") if verified_ops is None else verified_ops
        self.capabilities = {o: True for o in (x.strip() for x in ops.split(",")) if o in IMPLEMENTED}; self.dropped = 0
    def __repr__(self): return f"<RailCoreProvider key={'set' if self.key else 'missing'} ops={sorted(self.capabilities)}>"
    def classify_error(self, code, body, retry_after):
        ec = body.get("error", {}).get("code") if isinstance(body, dict) and isinstance(body.get("error"), dict) else None
        if code == 404 and ec == "NO_TRAINS_FOUND": raise NotOffered("no_trains")
        if code == 422: raise NotOffered(REASONS.get(ec, "not_offered"))
        return super().classify_error(code, body, retry_after)
    def _get(self, path, params=None):
        if not self.key: raise NotConfigured("RAILCORE_API_KEY is not set.")
        b = super()._get(path, params)
        if not isinstance(b, dict) or b.get("success") is not True or not isinstance(b.get("data"), dict): raise ProviderBadResponse("Provider returned an unexpected response.")
        return b
    def _check(self, **f):
        if not all(isinstance(v, str) and r.fullmatch(v) for v, r in f.values()): raise ProviderBadResponse("Invalid request parameters.")
    def trains_between(self, frm, to, date):
        self._check(a=(frm, R_STN), b=(to, R_STN), c=(date, R_DATE))
        try: b = self._get("/routes/trains", {"from": frm, "to": to, "date": date, "match": "station"})
        except NotOffered as e:
            if e.reason == "no_trains": return []
            raise
        d = b["data"]
        if d.get("journey_date") != date or not isinstance(d.get("trains"), list): raise ProviderBadResponse("Provider response did not match the request.")
        day, out = datetime.strptime(date, "%Y-%m-%d"), []
        for t in d["trains"]:
            if not (isinstance(t, dict) and all(isinstance(t.get(k), str) and t[k] for k in ("train_number", "train_name", "from_station_code", "to_station_code"))
                    and R_HM.fullmatch(str(t.get("departure_time", ""))) and R_HM.fullmatch(str(t.get("arrival_time", ""))) and _int(t.get("duration_minutes"))):
                raise ProviderBadResponse("Provider returned an unexpected train record.")
            h, m = map(int, t["departure_time"].split(":")); dep = day.replace(hour=h, minute=m, tzinfo=IST); arr = dep + timedelta(minutes=t["duration_minutes"])
            if arr.strftime("%H:%M") != t["arrival_time"] or (t["from_station_code"], t["to_station_code"]) != (frm, to): self.dropped += 1; continue  # inconsistent: never invent timings
            leg = {"train": t["train_number"], "name": t["train_name"], "frm": frm, "to": to, "dep": dep, "arr": arr}
            if isinstance(t.get("classes"), list): leg["classes"] = [c for c in t["classes"] if isinstance(c, str)]
            out.append(leg)
        return out
    def get_availability(self, train, frm, to, date, cls, quota):
        self._check(a=(train, R_TRAIN), b=(frm, R_STN), c=(to, R_STN), d=(date, R_DATE), e=(cls, R_CLS), f=(quota, R_QUOTA))
        b = self._get("/availability/seats", {"train_number": train, "from": frm, "to": to, "date": date, "class": cls, "quota": quota})
        d, meta = b["data"], b.get("meta") if isinstance(b.get("meta"), dict) else {}; fr = meta.get("freshness") if isinstance(meta.get("freshness"), dict) else {}
        if any(d.get(k) != v for k, v in (("train_number", train), ("from_station_code", frm), ("to_station_code", to), ("journey_date", date))) or d.get("quota") not in (None, quota):
            raise ProviderBadResponse("Provider response did not match the request.")
        c = next((x for x in d["classes"] if isinstance(x, dict) and x.get("class_code") == cls), None) if isinstance(d.get("classes"), list) else None
        if c is None: raise ProviderBadResponse("Provider response did not include the requested class.")
        mode = fr.get("mode") if isinstance(fr.get("mode"), str) else None; cp = c.get("confirmation_probability")
        return {"status": normalize_status(c), "fare": _int(c.get("total_fare")), "live": mode == "live", "freshness_mode": mode, "source": "railcore",
                "provider_updated_at": _ts(c.get("last_updated_at")), "retrieved_at": _ts(fr.get("retrieved_at")) or _ts(meta.get("timestamp")),
                "provider_status": c.get("status"), "availability_text": c.get("availability_text"), "request_id": meta.get("request_id"),
                "forecast": {"percentage": cp.get("percentage"), "label": cp.get("label")} if isinstance(cp, dict) else None}  # forecast is informational only: never used to confirm
