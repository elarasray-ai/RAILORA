"""Provider interface + capability registry. ALL adapters are UNVERIFIED stubs: no endpoints are invented."""
class NotConfigured(Exception): pass
class ProviderError(Exception): pass  # message must be safe to show users (no URLs, keys or raw upstream text)
class ProviderAuthError(ProviderError): pass
class ProviderRateLimited(ProviderError):
    def __init__(self, msg="Provider rate limit reached.", retry_after=None): super().__init__(msg); self.retry_after = retry_after
class ProviderQuotaExhausted(ProviderError): pass
class NotOffered(ProviderError):
    """A legitimate non-result (class/quota not offered, train not running, booking not open). NOT a provider failure."""
    def __init__(self, reason="not_offered"): super().__init__(f"Not offered: {reason}"); self.reason = reason
class ProviderUnavailable(ProviderError): pass
class ProviderBadResponse(ProviderError): pass
OPS = ("search_stations","search_trains","get_schedule","trains_between","get_availability","get_fare","get_running_status")
class Provider:
    name = "base"; capabilities = {}   # op -> True only after a successful live test
    def __getattr__(self, op):
        if op in OPS:
            def f(*a, **k): raise NotConfigured(f"{self.name}.{op} not configured/verified")
            return f
        raise AttributeError(op)
class RailCore(Provider): name = "railcore"            # UNVERIFIED
class RailRadar(Provider): name = "railradar"          # UNVERIFIED (reservation data is non-authoritative per its docs)
class IndianRailApi(Provider): name = "indianrailapi"  # UNVERIFIED
class Registry:
    def __init__(self, providers): self.p = providers
    def pick(self, op):
        for p in self.p:
            if p.capabilities.get(op): return p
        raise NotConfigured(f"no verified provider for {op}")
