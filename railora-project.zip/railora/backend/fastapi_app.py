"""UNTESTED here (fastapi not installable offline). Thin wrapper over the same WSGI app: uvicorn fastapi_app:app"""
from fastapi import FastAPI
from fastapi.middleware.wsgi import WSGIMiddleware
from api import make_app
app = FastAPI(title="RAILORA")
app.mount("/", WSGIMiddleware(make_app()))
